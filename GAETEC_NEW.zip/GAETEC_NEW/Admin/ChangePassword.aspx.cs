﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Data;
using System.Web.UI.WebControls;
using GAETEC_DL;

public partial class ChangePassword : System.Web.UI.Page
{
    CommonFuncs objCommon = new CommonFuncs();
    SampleSqlInjectionScreeningModule objsql = new SampleSqlInjectionScreeningModule();
    string ConnKey;
    protected void Page_Load(object sender, EventArgs e)
    {

        /*KILL COOKIE & clear Caching*/
        PrevBrowCache.enforceNoCache();
        if ((Request.ServerVariables["HTTP_REFERER"] == null) || (Request.ServerVariables["HTTP_REFERER"] == ""))
        {
            Response.Redirect("../Error.aspx");
        }
        else
        {
            string http_ref = Request.ServerVariables["HTTP_REFERER"].Trim();
            string http_hos = Request.ServerVariables["HTTP_HOST"].Trim();
            int len = http_hos.Length;
            if (http_ref.IndexOf(http_hos, 0) < 0)
            {
                Response.Redirect("../Error.aspx");
            }
        }

        /*KILL COOKIE & clear Caching*/
        //  PrevBrowCache.enforceNoCache();
        if (Session["Role"] != null && Session["AuthToken"] != null && Request.Cookies["AuthToken"] != null)
        {
            if (!Session["AuthToken"].ToString().Equals(Request.Cookies["AuthToken"].Value))
            {
                Response.Redirect("../Error.aspx");
            }
        }
        else
        {
            Response.Redirect("~/Error.aspx");
        }
        ConnKey = Session["ConnKey"].ToString();
        if (!IsPostBack)
        {
            ValidChars();
            random();
            Session["keyGen"] = Guid.NewGuid().ToString("N").Substring(0, 16);
            lblUsrName.Text = Session["UsrName"].ToString();

            lblUsrName.Text = Session["UsrName"].ToString();
            lblDate.Text = DateTime.Now.ToString("dd-MM-yyyy");

        }
        inputcheck();
    }
    public void inputcheck()
    {
        string url = Request.Url.ToString();
        foreach (string key in Request.QueryString)
            objsql.CheckInput(Request.QueryString[key]);
        foreach (string key in Request.Cookies)
            objsql.CheckInput(Request.Cookies[key].Value);
    }
    public void ValidChars()
    {
        foreach (string key in Request.Form)
        {
            if (!key.Contains("__"))
            {
                objsql.CheckInput(Request.Form[key]);
            }
        }
    }
    public void random()
    {
        try
        {
            string strString = "abcdefghijklmnpqrstuvwxyzABCDQEFGHIJKLMNOPQRSTUVWXYZ1234567890";
            string num = "";
            Random rm = new Random();
            for (int i = 0; i < 16; i++)
            {
                int randomcharindex = rm.Next(0, strString.Length);
                char randomchar = strString[randomcharindex];
                num += Convert.ToString(randomchar);
            }

            Response.Cookies.Add(new HttpCookie("ASPFIXATION2", num));
            Session["hf"] = num;
            Session["ASPFIXATION2"] = num;
        }
        catch (Exception ex)
        {
            Response.Redirect("~/Error.aspx");
        }
    }
    public void check()
    {
        try
        {
            string cookie_value = null;
            string session_value = null;
            //cookie_value = System.Web.HttpContext.Current.Request.Cookies["ASPFIXATION2"].Value;
            cookie_value = Session["hf"].ToString();
            session_value = System.Web.HttpContext.Current.Session["ASPFIXATION2"].ToString();
            if (cookie_value != session_value)
            {
                System.Web.HttpContext.Current.Session.Abandon();
                HttpContext.Current.Response.Buffer = false;
                HttpContext.Current.Response.Redirect("../Error.aspx");
            }
        }
        catch (Exception ex)
        {
            Response.Redirect("../Error.aspx");
        }
    }
    public string ShaEncrypt(string Ptext)
    {
        string hash = "";
        System.Security.Cryptography.SHA256CryptoServiceProvider m1 = new System.Security.Cryptography.SHA256CryptoServiceProvider();
        byte[] s1 = System.Text.Encoding.ASCII.GetBytes(Ptext);
        s1 = m1.ComputeHash(s1);
        foreach (byte bt in s1)
        {
            hash = hash + bt.ToString("x2");
        }
        return hash;
    }
    protected void btnSubmit_Click(object sender, EventArgs e)
    {
        try
        {
            check();
            //ValidChars();
            string IP = HttpContext.Current.Request.UserHostAddress;
            Login_DL objLogin = new Login_DL();
            DataTable dtLogin = objLogin.getLoginDetails(Session["UsrName"].ToString(), ConnKey);
            int i = 0;
            if (dtLogin.Rows.Count > 0)
            {
                //old password Sha256
                string oldPassword1 = txtOldPwdHash.Value;
                //DB  password Sha256
                string password = dtLogin.Rows[0]["Password"].ToString();
                //new password Sha256
                string value = txtNewPwdHash.Value;
                if (password.ToLower() != value.ToLower())
                {
                    if (oldPassword1.ToLower() == oldPassword1.ToLower())
                    {
                        objLogin.changepassword(Session["UsrName"].ToString(), value, IP, ConnKey);
                        //objLogin.UpdateLoginDetails(Application["Uname"].ToString(), ConfigurationManager.ConnectionStrings["ConnectionString"].ToString(), "Z");
                        objCommon.ShowAlertMessage("Password successfully changed");
                        Response.Redirect("../Login.aspx");

                    }
                    else
                    {
                        objCommon.ShowAlertMessage("Password Not Matched");
                    }
                }
                else
                {
                    if (i == 0)
                    {
                        objCommon.ShowAlertMessage("New Password should not be same as old password");
                    }
                }
            }
            else
            {

                objCommon.ShowAlertMessage("New Password should not be same as old password");
            }
        }
        catch (Exception ex)
        {
            ExceptionLogging.SendExcepToDB(ex, Session["UsrName"].ToString(), Request.ServerVariables["REMOTE_ADDR"].ToString());
            // Response.Redirect("~/Error.aspx");
        }
    }
    public static void ShowAlertMessage(string error)
    {
        Page page = HttpContext.Current.Handler as Page;
        if (page != null)
        {
            error = error.Replace("'", "\'");
            ScriptManager.RegisterStartupScript(page, page.GetType(), "err_msg", "alert('" + error + "');", true);
        }
    }
    protected void txtOpwd_TextChanged(object sender, EventArgs e)
    {

    }
    protected void txtNpwd_TextChanged(object sender, EventArgs e)
    {

    }
    protected void txtCpwd_TextChanged(object sender, EventArgs e)
    {

    }
}