﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Data;
using System.IO;
using System.Web.UI.WebControls;
using GAETEC_BE;
using GAETEC_DL;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.IO.Compression;

public partial class Admin_ContentData : System.Web.UI.Page
{
    CommonFuncs objCommon = new CommonFuncs();
    Admin_BE objBE = new Admin_BE();
    Admin_DL objDL = new Admin_DL();
    DataTable ddt = new DataTable();
    SampleSqlInjectionScreeningModule objsql = new SampleSqlInjectionScreeningModule();
    string ConnKey, UserName, Role;
    int j = 0;
    static byte[] barrImg;
    protected void Page_Load(object sender, EventArgs e)
    {

        if ((Request.ServerVariables["HTTP_REFERER"] == null) || (Request.ServerVariables["HTTP_REFERER"] == ""))
        {
            Response.Redirect("../Error.aspx");
        }
        else
        {
            string http_ref = Request.ServerVariables["HTTP_REFERER"].Trim();
            string http_hos = Request.ServerVariables["HTTP_HOST"].Trim();
            int len = http_hos.Length;
            if (http_ref.IndexOf(http_hos, 0) < 0)
            {
                Response.Redirect("../Error.aspx");
            }
        }
        /*KILL COOKIE & clear Caching*/
        PrevBrowCache.enforceNoCache();
        if (Session["Role"] != null && Session["AuthToken"] != null && Request.Cookies["AuthToken"] != null)
        {
            if (!Session["AuthToken"].ToString().Equals(Request.Cookies["AuthToken"].Value))
            {
                Response.Redirect("../Error.aspx");
            }
            else
            {
                ConnKey = Session["ConnKey"].ToString();
                UserName = Session["UsrName"].ToString();
                Role = Session["RoleName"].ToString();
            }
        }

        if (!IsPostBack)
        {
            inputcheck();
            MainMenu();
            random();
            BindContentDtls();
            BindGrid();
            CreateRow();
        }

    }
    public void inputcheck()
    {
        string url = Request.Url.ToString();
        foreach (string key in Request.QueryString)
            objsql.CheckInput(Request.QueryString[key]);
        foreach (string key in Request.Cookies)
            objsql.CheckInput(Request.Cookies[key].Value);
    }
    public void BindGrid()
    {
        ddt = CreateDt();
        GVEvent.Visible = true;
        ddt.Rows.Add();
        GVEvent.DataSource = ddt;
        GVEvent.DataBind();
    }
    public void random()
    {
        try
        {
            string strString = "abcdefghijklmnpqrstuvwxyzABCDQEFGHIJKLMNOPQRSTUVWXYZ1234567890";
            string num = "";
            Random rm = new Random();
            for (int i = 0; i < 16; i++)
            {
                int randomcharindex = rm.Next(0, strString.Length);
                char randomchar = strString[randomcharindex];
                num += Convert.ToString(randomchar);
            }

            Response.Cookies.Add(new HttpCookie("ASPFIXATION2", num));
            hf.Value = num;
            Session["ASPFIXATION2"] = num;
        }
        catch (Exception ex)
        {
            Response.Redirect("~/Error.aspx", false);
        }
    }
    public void MainMenu()
    {
        try
        {
            objBE.Flag = "M";
            DataTable dt = objDL.Menus(objBE, ConnKey);
            if (dt.Rows.Count > 0)
            {
                objCommon.BindDropDownLists(ddlMainMenu, dt, "MainMenuName", "MainMenuId", "0");
            }
            BindContentDtls();
        }
        catch (Exception ex)
        {
            ExceptionLogging.SendExcepToDB(ex, "", Request.ServerVariables["REMOTE_ADDR"].ToString());
            Response.Redirect("../Error.aspx");
        }
    }
    public void BindSubMenu()
    {
        try
        {
            objBE.Flag = "S";
            objBE.MainMenu = ddlMainMenu.SelectedValue.Trim();
            DataTable dt = objDL.Menus(objBE, ConnKey);
            if (dt.Rows.Count > 0)
            {
                ddlSubMenu.Enabled = true;
                objCommon.BindDropDownLists(ddlSubMenu, dt, "SubMenuName", "SubMenuId", "0");
            }

            else
            {
                ddlSubMenu.Enabled = false;
                ddlChildMenu.Enabled = false;
                ddlSubMenu.ClearSelection();
                ddlChildMenu.ClearSelection();
            }
            BindContentDtls();
        }
        catch (Exception ex)
        {
            ExceptionLogging.SendExcepToDB(ex, "", Request.ServerVariables["REMOTE_ADDR"].ToString());
            Response.Redirect("../Error.aspx");
        }
    }
    public void BindChildMenu()
    {
        try
        {
            objBE.Flag = "C";
            objBE.MainMenu = ddlMainMenu.SelectedValue.Trim();
            objBE.SubMenu = ddlSubMenu.SelectedValue.Trim();
            DataTable dt = objDL.Menus(objBE, ConnKey);
            if (dt.Rows.Count > 0)
            {
                ddlChildMenu.Enabled = true;
                objCommon.BindDropDownLists(ddlChildMenu, dt, "ChildMenuName", "ChildMenuId", "0");
            }
            else
            {
                ddlChildMenu.Enabled = false;
                ddlChildMenu.ClearSelection();
            }
            BindContentDtls();

        }
        catch (Exception ex)
        {
            ExceptionLogging.SendExcepToDB(ex, "", Request.ServerVariables["REMOTE_ADDR"].ToString());
            Response.Redirect("../Error.aspx");
        }
    }
    protected void ddlMainMenu_SelectedIndexChanged(object sender, EventArgs e)
    {
        BindSubMenu();
    }
    protected void ddlSubMenu_SelectedIndexChanged(object sender, EventArgs e)
    {
        BindChildMenu();
    }
    public void BindContentDtls()
    {
        try
        {
            objBE.Flag = "R1";
            objBE.MainMenu = ddlMainMenu.SelectedValue.Trim();
            objBE.SubMenu = ddlSubMenu.SelectedValue.Trim();
            objBE.ChildMenu = ddlChildMenu.SelectedIndex <= 0 ? null : ddlChildMenu.SelectedValue;
            DataTable dt = objDL.ContentManagment(objBE, ConnKey);
            if (dt.Rows.Count > 0)
            {
                GridView1.Visible = true;
                GridView1.DataSource = dt;
                GridView1.DataBind();

                GridView1.HeaderRow.Cells[0].Attributes["data-class"] = "expand";

                //Attribute to hide column in Phone.
                GridView1.HeaderRow.Cells[1].Attributes["data-hide"] = "phone";
                GridView1.HeaderRow.Cells[2].Attributes["data-hide"] = "phone";
                GridView1.HeaderRow.Cells[3].Attributes["data-hide"] = "phone";
                GridView1.HeaderRow.Cells[4].Attributes["data-hide"] = "phone";
                GridView1.HeaderRow.Cells[5].Attributes["data-hide"] = "phone";
                GridView1.HeaderRow.Cells[6].Attributes["data-hide"] = "phone";
                GridView1.HeaderRow.Cells[7].Attributes["data-hide"] = "phone";
                //gvNotification.HeaderRow.Cells[8].Attributes["data-hide"] = "phone";
                //gvVillages.HeaderRow.Cells[2].Attributes["data-hide"] = "phone";


                //Adds THEAD and TBODY to GridView.
                GridView1.HeaderRow.TableSection = TableRowSection.TableHeader;
            }
            else
            {
                GridView1.Visible = false;
                objCommon.ShowAlertMessage("No Data Found");
            }
        }
        catch (Exception ex)
        {
            ExceptionLogging.SendExcepToDB(ex, "Admin", Request.ServerVariables["REMOTE_ADDR"].ToString());
            Response.Redirect("../Error.aspx");
        }
    }
    protected bool Validatefun()
    {
        if (ddlMainMenu.SelectedValue == "")
        {
            objCommon.ShowAlertMessage("Please Select Main Menu");
            ddlMainMenu.Focus();
            return false;
        }

        if (txtcontent.Text == "")
        {
            objCommon.ShowAlertMessage("Enter Content Description");
            txtcontent.Focus();
            return false;
        }
        return true;
    }
    public byte[] GetImage(byte[] img)
    {
        //return "data:image/jpg;base64," + Convert.ToBase64String((byte[])img);

        //MemoryStream output = new MemoryStream();
        //using (DeflateStream dstream = new DeflateStream(output, CompressionMode.Compress))
        //{
        //    dstream.Write(data, 0, data.Length);
        //}
        byte[] data = (byte[])img;
        Stream output = new MemoryStream(data);
        byte[] bytee = ResizeImage(0.5, output);
        return bytee;
        //return "";

    }
    public byte[] ResizeImage(double scalefactor, Stream byt)
    {
        using (var image = System.Drawing.Image.FromStream(byt))
        {
            MemoryStream newmemorystream = new MemoryStream();
            var newwidth = (int)(image.Width * scalefactor);
            var newheieght = (int)(image.Height * scalefactor);
            var resizeimage = new Bitmap(newwidth, newheieght);
            var resizegraph = Graphics.FromImage(resizeimage);
            resizegraph.CompositingQuality = CompositingQuality.HighQuality;
            resizegraph.SmoothingMode = SmoothingMode.HighQuality;
            resizegraph.InterpolationMode = InterpolationMode.HighQualityBicubic;
            var imagerectangle = new Rectangle(0, 0, newwidth, newheieght);
            resizegraph.DrawImage(image, imagerectangle);
            resizeimage.Save(newmemorystream, System.Drawing.Imaging.ImageFormat.Jpeg);
            byte[] ReturnedThumbnail;
            ReturnedThumbnail = newmemorystream.ToArray();
            return ReturnedThumbnail;
        }
    }
    public static byte[] Compress(byte[] data)
    {
        MemoryStream output = new MemoryStream();
        using (DeflateStream dstream = new DeflateStream(output, CompressionMode.Compress))
        {
            dstream.Write(data, 0, data.Length);
        }
        return output.ToArray();
    }
    protected void View(object sender, EventArgs e)
    {
        int id = int.Parse((sender as LinkButton).CommandArgument);
        objBE.Flag = "V";
        objBE.Id = id.ToString();
        DataTable dt = objDL.ContentManagment(objBE, ConnKey);
        if (dt.Rows.Count > 0)
        {
            string img = Convert.ToBase64String((byte[])dt.Rows[0]["Document_Image"]);
            if (!string.IsNullOrEmpty(img))
            {
                Response.Clear();
                Response.Buffer = true;
                Response.ContentType = MimeType.GetMimeType((byte[])dt.Rows[0]["Document_Image"], dt.Rows[0]["File_Name"].ToString());
                Response.AddHeader("content-disposition", "attachement;filename=" + dt.Rows[0]["File_Name"].ToString()); // to open file prompt Box open or Save file  
                Response.Charset = "";
                Response.Cache.SetCacheability(HttpCacheability.NoCache);
                Response.BinaryWrite((byte[])dt.Rows[0]["Document_Image"]);
                Response.End();
            }
        }

    }
    protected void GridView1_RowDataBound(object sender, GridViewRowEventArgs e)
    {
        try
        {
            if (e.Row.RowType == DataControlRowType.DataRow)
            {
                Label lblDocumentImage = (Label)e.Row.FindControl("lblFileName");
                if (string.IsNullOrEmpty(lblDocumentImage.Text))
                {
                    LinkButton lnkView = (LinkButton)e.Row.FindControl("lnkView");
                    Label lblDocument = (Label)e.Row.FindControl("lblDocument");
                    lblDocument.Visible = true;
                    lblDocument.Text = "No Document";
                    lnkView.Visible = false;
                }
            }
        }
        catch (Exception ex)
        {
            ExceptionLogging.SendExcepToDB(ex, Session["UsrName"].ToString(), Request.ServerVariables["REMOTE_ADDR"].ToString());
            Response.Redirect("../Error.aspx");
        }
    }
    protected DataTable CreateDt()
    {
        DataTable dt = new DataTable();
        dt.Columns.Add(new DataColumn("File_Name", typeof(string)));
        dt.Columns.Add(new DataColumn("File_Type", typeof(string)));
        dt.Columns.Add(new DataColumn("Document_Image", typeof(string)));
        return dt;
    }
    protected DataTable CreateDtF()
    {
        DataTable dt = new DataTable();
        dt.Columns.Add(new DataColumn("File_Name", typeof(string)));
        dt.Columns.Add(new DataColumn("File_Type", typeof(string)));
        dt.Columns.Add(new DataColumn("Document_Image", typeof(byte[])));
        return dt;
    }
    public DataTable CreateRow()
    {
        DataTable dt1 = new DataTable();
        dt1.Columns.Add(new DataColumn("File_Name", typeof(string)));
        dt1.Columns.Add(new DataColumn("File_Type", typeof(string)));
        dt1.Columns.Add(new DataColumn("Document_Image", typeof(byte[])));
        //dt1.Rows.Add();
        //GVEvent.DataSource = dt1;
        //GVEvent.DataBind();
        //ViewState["GVEvent"] = dt1;
        return dt1;

    }
    //protected void GVEvent_RowCommand(object sender, GridViewCommandEventArgs e)
    //{
    //    try
    //    {
    //        string path = "";
    //        GridViewRow gvrow = (GridViewRow) ((Control) e.CommandSource).NamingContainer;

    //        if (e.CommandName == "Add")
    //        {
    //            //DataTable AddRow = new DataTable();
    //            //AddRow.Columns.Add(new DataColumn("File_Name", typeof(string)));
    //            //AddRow.Columns.Add(new DataColumn("File_Type", typeof(string)));
    //            //AddRow.Columns.Add(new DataColumn("Document_Image", typeof(byte[])));
    //            DataTable AddRow = CreateRow();
    //            int j = 0;
    //            foreach (GridViewRow gr in GVEvent.Rows)
    //            {
    //                FileUpload FileUpdphoto = (FileUpload) gr.FindControl("UpldEventUpload");
    //                Label lblDocumentImage = (Label) gr.FindControl("lblDocumentImage");
    //                Label lblFName = (Label) gr.FindControl("lblFName");
    //                if (FileUpdphoto.HasFile)
    //                {
    //                    Stream fs = FileUpdphoto.PostedFile.InputStream;
    //                    BinaryReader br = new BinaryReader(fs);
    //                    Byte[] bytes = br.ReadBytes((Int32) fs.Length);
    //                    string mime1 = MimeType.GetMimeType(bytes, FileUpdphoto.PostedFile.FileName);
    //                    lblDocumentImage.Text = Convert.ToBase64String(bytes);
    //                    if (mime1 == "image/jpeg" || mime1 == "image/png")
    //                    {
    //                        int len = FileUpdphoto.PostedFile.ContentLength;
    //                        if ((len / 1024) > 4096)
    //                        {
    //                            objCommon.ShowAlertMessage("File size is exceeded");
    //                            FileUpdphoto.Focus();
    //                            return;
    //                        }
    //                        if (FileUpdphoto.PostedFile.FileName != "")
    //                        {
    //                            AddRow.Rows.Add();
    //                            AddRow.Rows[j]["File_Name"] = FileUpdphoto.PostedFile.FileName;
    //                            AddRow.Rows[j]["File_Type"] = FileUpdphoto.PostedFile.ContentType;
    //                            AddRow.Rows[j]["Document_Image"] = bytes;
    //                            j++;
    //                        }
    //                    }
    //                    else
    //                    {
    //                        objCommon.ShowAlertMessage("Please uploaad Valid image file");
    //                        FileUpdphoto.Focus();
    //                        return;
    //                    }
    //                }
    //                else
    //                {
    //                    if (FileUpdphoto.PostedFile.FileName == "")
    //                    {
    //                        AddRow.Rows.Add();
    //                        AddRow.Rows[j]["File_Name"] = "";
    //                        AddRow.Rows[j]["File_Type"] = "";
    //                        AddRow.Rows[j]["Document_Image"] = null;
    //                        j++;
    //                    }
    //                }
    //            }
    //            AddRow.Rows.Add();
    //            ViewState["GVEvent"] = AddRow;
    //            GVEvent.DataSource = AddRow;
    //            GVEvent.DataBind();
    //        }
    //        if (e.CommandName == "Remove")
    //        {
    //            ddt = CreateDt();
    //            foreach (GridViewRow gr in GVEvent.Rows)
    //            {
    //                ddt.Rows.Add();
    //                if (((FileUpload) gr.FindControl("UpldEventUpload")).HasFile)
    //                {
    //                    if ((((FileUpload) gr.FindControl("UpldEventUpload")).PostedFile.ContentType != "image/jpeg" && ((FileUpload) gr.FindControl("UpldEventUpload")).PostedFile.ContentType != "image/png") && ((FileUpload) gr.FindControl("UpldEventUpload")).PostedFile.ContentType != "application/pdf")
    //                    {
    //                        objCommon.ShowAlertMessage("Please Upload Valid Image File/pdf file");
    //                        return;
    //                    }
    //                    Stream fs = ((FileUpload) gr.FindControl("UpldEventUpload")).PostedFile.InputStream;
    //                    BinaryReader br = new BinaryReader(fs); //reads the binary files  
    //                    Byte[] bytes = br.ReadBytes((Int32) fs.Length);
    //                    if (((FileUpload) gr.FindControl("UpldEventUpload")).PostedFile.ContentLength > 2097152)
    //                    {
    //                        objCommon.ShowAlertMessage("File Size Exceeded Please upload less than 2mb size file");
    //                        return;
    //                    }
    //                    ddt.Rows[j]["File_Name"] = Path.GetFileNameWithoutExtension(((FileUpload) gr.FindControl("UpldEventUpload")).PostedFile.FileName);
    //                    ddt.Rows[j]["File_Type"] = Path.GetExtension(((FileUpload) gr.FindControl("UpldEventUpload")).PostedFile.FileName);
    //                    ddt.Rows[j]["Document_Image"] = Convert.ToBase64String(bytes);
    //                }
    //                //else
    //                //{
    //                //    if (((Label) gr.FindControl("lblFName")).Text.Trim() != "")
    //                //    {
    //                //        ddt.Rows[j]["File_Name"] = ((Label) gr.FindControl("lblFName")).Text.Trim();
    //                //        ddt.Rows[j]["File_Type"] = ((Label) gr.FindControl("lblFType")).Text.Trim();
    //                //        //ddt.Rows[j]["Document_Image"] = ((Label) gr.FindControl("lblDocumentImage")).Text.Trim();
    //                //    }
    //                //}
    //                j++;
    //            }
    //            if (ddt.Rows.Count > 0)
    //            {
    //                if (((Label) gvrow.FindControl("lblFName")).Text != "")
    //                    File.Delete(path);
    //                ddt.Rows.RemoveAt(gvrow.RowIndex);
    //                if (ddt.Rows.Count == 0)
    //                {
    //                    ddt.Rows.Add();
    //                }
    //                GVEvent.DataSource = ddt;
    //                GVEvent.DataBind();
    //            }
    //        }
    //    }
    //    catch (Exception ex)
    //    {
    //        ExceptionLogging.SendExcepToDB(ex, "", Request.ServerVariables["REMOTE_ADDR"].ToString());
    //        //Response.Redirect("../Error.aspx");
    //    }
    //}
    protected void GridView1_RowCommand(object sender, GridViewCommandEventArgs e)
    {
        try
        {
            GridViewRow gvrow = (GridViewRow)((Control)e.CommandSource).NamingContainer;
            if (e.CommandName == "View")
            {
                int id = int.Parse((sender as LinkButton).CommandArgument);
                objBE.Flag = "V";
                objBE.Id = id.ToString();
                DataTable dt = objDL.ContentManagment(objBE, ConnKey);
                if (dt.Rows.Count > 0)
                {
                    string img = Convert.ToBase64String((byte[])dt.Rows[0]["Document_Image"]);

                    if (!string.IsNullOrEmpty(img))
                    {
                        Response.Clear();
                        Response.Buffer = true;
                        Response.ContentType = "application/" + dt.Rows[0]["File_Type"].ToString();
                        Response.AddHeader("content-disposition", "attachement;filename=" + dt.Rows[0]["File_Name"].ToString() + "." + dt.Rows[0]["File_Type"].ToString()); // to open file prompt Box open or Save file  
                        Response.Charset = "";
                        Response.Cache.SetCacheability(HttpCacheability.NoCache);
                        Response.BinaryWrite((byte[])dt.Rows[0]["Document_Image"]);
                        Response.End();
                    }
                }

            }
        }
        catch (Exception ex)
        {
            ExceptionLogging.SendExcepToDB(ex, Session["UsrName"].ToString(), Request.ServerVariables["REMOTE_ADDR"].ToString());
            Response.Redirect("../Error.aspx");
        }
    }
    protected void linkDelete_OnClick(object sender, EventArgs e)
    {
        try
        {
            LinkButton Lnkdelete = (LinkButton)sender;
            GridViewRow gdRow = (GridViewRow)Lnkdelete.NamingContainer;
            Label Uid = gdRow.FindControl("lblContentId") as Label;
            objBE.Id = Uid.Text;
            DataTable dt = new DataTable();
            objBE.Flag = "D";
            dt = objDL.ContentManagment(objBE, ConnKey);
            if (dt.Rows.Count > 0)
            {
                objCommon.ShowAlertMessage("Record Not Deleted");
            }
            else
            {
                objCommon.ShowAlertMessage("Record Deleted Successfully");
                BindContentDtls();
                // btnUpdate.Visible = false;
                btnsubmit.Visible = true;
            }
        }
        catch (Exception ex)
        {
            ExceptionLogging.SendExcepToDB(ex, "Admin", Request.ServerVariables["REMOTE_ADDR"].ToString());
            Response.Redirect("~/Error.aspx", false);
        }
    }
    protected void linkedit_Click(object sender, EventArgs e)
    {
        try
        {
            LinkButton lnkEdit = (LinkButton)sender;
            GridViewRow gdRow = (GridViewRow)lnkEdit.NamingContainer;
            Label content = gdRow.FindControl("lblContent") as Label;
            Label ContentId = gdRow.FindControl("lblContentId") as Label;
            hdnUid.Value = ContentId.Text;

            //MainMenu();
            //Label MainMenuId = gdRow.FindControl("lblMainMenuId") as Label;
            //ddlMainMenu.SelectedValue = MainMenuId.Text;
            //BindSubMenu();
            //Label SubMenuId = gdRow.FindControl("lblSubMenuId") as Label;
            //ddlSubMenu.SelectedValue = SubMenuId.Text;
            //BindChildMenu();
            //Label ChildMenuId = gdRow.FindControl("lblChildMenuId") as Label;
            //ddlChildMenu.SelectedValue = ChildMenuId.Text;

            //txtcontent.Content = content.Text;

            //Label lblFileName = gdRow.FindControl("lblFileName") as Label;
            //Label lblFileType = gdRow.FindControl("lblFileType") as Label;
            //Label lblDocumentImage = gdRow.FindControl("lblDocumentImage") as Label;

            //ViewState["DocumentImage"] = lblDocumentImage.Text;
            //ViewState["FileName"] = lblFileName.Text;
            //ViewState["FileType"] = lblFileType.Text;
            //ImageButton AddRows = gdRow.FindControl("imgBtnAdd") as ImageButton;
            //ImageButton RemoveRow = gdRow.FindControl("imgBtnRemove") as ImageButton;
            //objBE.MainMenu = ddlMainMenu.SelectedValue.Trim();
            //objBE.SubMenu = ddlSubMenu.SelectedValue.Trim();
            //objBE.ChildMenu = ddlChildMenu.SelectedIndex <= 0 ? null : ddlChildMenu.SelectedValue;
            objBE.Flag = "Edit";

            objBE.Id = ContentId.Text;
            DataTable dt = objDL.ContentManagment(objBE, ConnKey);
            if (dt.Rows.Count > 0)
            {
                ddlMainMenu.SelectedValue = dt.Rows[0]["MainMenuId"].ToString();
                BindSubMenu();
                ddlSubMenu.SelectedValue = dt.Rows[0]["SubMenuId"].ToString();
                BindChildMenu();
                ddlChildMenu.SelectedValue = dt.Rows[0]["ChildMenuId"].ToString();
                txtcontent.Text = dt.Rows[0]["ContentDisc"].ToString();
                ViewState["DocumentImage"] = dt.Rows[0]["Document_Image"].ToString();
                ViewState["FileName"] = dt.Rows[0]["File_Name"].ToString();
                ViewState["FileType"] = dt.Rows[0]["File_Type"].ToString();
                barrImg = (byte[])dt.Rows[0]["Document_Image"];
            }
            btnsubmit.Visible = false;
            btnUpdate.Visible = true;
        }
        catch (Exception ex)
        {
            ExceptionLogging.SendExcepToDB(ex, "ContentDetails", Request.ServerVariables["REMOTE_ADDR"].ToString());
            Response.Redirect("../Error.aspx");
        }
    }
    protected void btnsubmit_Click(object sender, EventArgs e)
    {
        try
        {
            int i = 0;
            if (Validatefun())
            {
                lblContentDtls.Text = txtcontent.Text;
                objBE.contentDesc = lblContentDtls.Text;

                //DataTable ddt = CreateDtF();
                //foreach (GridViewRow gr in GVEvent.Rows)
                //{
                //    Label FileName = (Label) gr.FindControl("lblFName");
                //    FileUpload FileUpdphoto = (FileUpload) gr.FindControl("UpldEventUpload");

                //    if (FileUpdphoto.HasFile)
                //    {
                //        Stream fs = FileUpdphoto.PostedFile.InputStream;
                //        BinaryReader br = new BinaryReader(fs);
                //        Byte[] bytes = br.ReadBytes((Int32) fs.Length);
                //        string mime1 = MimeType.GetMimeType(bytes, FileUpdphoto.PostedFile.FileName);
                //        if (mime1 == "image/jpeg" || mime1 == "image/png")
                //        {
                //            int len = FileUpdphoto.PostedFile.ContentLength;
                //            if ((len / 1024) > 4096)
                //            {

                //                objCommon.ShowAlertMessage("File size is exceeded");
                //                FileUpdphoto.Focus();
                //                return;
                //            }
                //            ddt.Rows.Add();
                //            ddt.Rows[j]["File_Name"] = FileUpdphoto.PostedFile.FileName;
                //            ddt.Rows[j]["File_Type"] = FileUpdphoto.PostedFile.ContentType;
                //            ddt.Rows[j]["Document_Image"] = bytes;
                //            j++;
                //        }
                //        else
                //        {
                //            objCommon.ShowAlertMessage("Please Upload Valid Image File");
                //            FileUpdphoto.Focus();
                //            return;
                //        }
                //    }
                //    else
                //    {
                //        ddt.Rows.Add();
                //        ddt.Rows[j]["File_Name"] = null;
                //        ddt.Rows[j]["File_Type"] = null;
                //        ddt.Rows[j]["Document_Image"] = null;
                //        j++;
                //    }
                //}

                ddt = CreateDtF();
                foreach (GridViewRow gr in GVEvent.Rows)
                {
                    ddt.Rows.Add();
                    if (((FileUpload)gr.FindControl("UpldEventUpload")).HasFile)
                    {
                        if ((((FileUpload)gr.FindControl("UpldEventUpload")).PostedFile.ContentType != "image/jpeg" && ((FileUpload)gr.FindControl("UpldEventUpload")).PostedFile.ContentType != "image/png") && ((FileUpload)gr.FindControl("UpldEventUpload")).PostedFile.ContentType != "application/pdf")
                        {
                            objCommon.ShowAlertMessage("Please Upload Valid Image file");
                            return;
                        }
                        Stream fs = ((FileUpload)gr.FindControl("UpldEventUpload")).PostedFile.InputStream;
                        BinaryReader br = new BinaryReader(fs); //reads the binary files  
                        Byte[] bytes = br.ReadBytes((Int32)fs.Length);
                        //if (((FileUpload)gr.FindControl("UpldEventUpload")).PostedFile.ContentLength > 6e+6)
                        //{
                        //    objCommon.ShowAlertMessage("File Size Exceeded Please upload less than 6mb size file");
                        //    return;
                        //}
                        ddt.Rows[j]["File_Name"] = Path.GetFileNameWithoutExtension(((FileUpload)gr.FindControl("UpldEventUpload")).PostedFile.FileName);
                        ddt.Rows[j]["File_Type"] = Path.GetExtension(((FileUpload)gr.FindControl("UpldEventUpload")).PostedFile.FileName);
                        ddt.Rows[j]["Document_Image"] = bytes;
                        if ((((FileUpload)gr.FindControl("UpldEventUpload")).PostedFile.ContentType == "image/jpeg" || ((FileUpload)gr.FindControl("UpldEventUpload")).PostedFile.ContentType == "image/png") || (((FileUpload)gr.FindControl("UpldEventUpload")).PostedFile.ContentType == "image/jpg"))
                        {
                            ddt.Rows[j]["Document_Image"] = GetImage(bytes);
                        }
                    }
                    else
                    {
                        if (((Label)gr.FindControl("lblFName")).Text.Trim() != "" && ((Label)gr.FindControl("lblFName")).Text.Trim() != null)
                        {
                            ddt.Rows[j]["File_Name"] = ((Label)gr.FindControl("lblFName")).Text.Trim();
                            ddt.Rows[j]["File_Type"] = ((Label)gr.FindControl("lblFType")).Text.Trim();
                            ddt.Rows[j]["Document_Image"] = Convert.FromBase64String(((Label)gr.FindControl("lblDocumentImage")).Text.Trim());
                        }
                    }
                    j++;
                }
                objBE.MainMenu = ddlMainMenu.SelectedValue.Trim();
                objBE.SubMenu = ddlSubMenu.SelectedValue.Trim();
                objBE.ChildMenu = ddlChildMenu.SelectedValue.Trim();
                lblContentDtls.Text = txtcontent.Text;
                objBE.contentDesc = lblContentDtls.Text;
                objBE.UserName = UserName;
                objBE.Ip = Request.ServerVariables["REMOTE_ADDR"].ToString();
                objBE.Flag = "I";
                objBE.TVP = ddt;
                DataTable dt = new DataTable();
                dt = objDL.ContentManagment(objBE, ConnKey);
                if (dt.Rows.Count > 0)
                {
                    objCommon.ShowAlertMessage(dt.Rows[0][0].ToString());
                }
                else
                {
                    GridView1.DataSource = dt;
                    GridView1.DataBind();
                    objCommon.ShowAlertMessage("Details Inserted Successfully");
                    txtcontent.Text = "";
                    ddlSubMenu.ClearSelection();
                    ddlChildMenu.ClearSelection();
                }
                BindContentDtls();
            }
        }
        catch (Exception ex)
        {
            ExceptionLogging.SendExcepToDB(ex, Session["UsrName"].ToString(), Request.ServerVariables["REMOTE_ADDR"].ToString());
            Response.Redirect("~/Error.aspx", false);
        }
    }
    protected void btnUpdate_Click(object sender, EventArgs e)
    {
        try
        {
            int i = 0;
            if (Validatefun())
            {
                ddt = CreateDtF();
                foreach (GridViewRow gr in GVEvent.Rows)
                {
                    Label FileName = (Label)gr.FindControl("lblFName");
                    FileUpload FileUpdphoto = (FileUpload)gr.FindControl("UpldEventUpload");
                    if (FileUpdphoto.HasFile)
                    {
                        Stream fs = FileUpdphoto.PostedFile.InputStream;
                        BinaryReader br = new BinaryReader(fs);
                        Byte[] bytes = br.ReadBytes((Int32)fs.Length);
                        string mime1 = MimeType.GetMimeType(bytes, FileUpdphoto.PostedFile.FileName);
                        //string mime1 = FileUpdphoto.PostedFile.ContentType;
                        if (mime1 == "image/jpeg" || mime1 == "image/png")
                        {
                            int len = FileUpdphoto.PostedFile.ContentLength;
                            if ((len / 1024) > 4096)
                            {
                                objCommon.ShowAlertMessage("File size is exceeded");
                                FileUpdphoto.Focus();
                                return;
                            }
                            objBE.File_Name = FileUpdphoto.PostedFile.FileName;
                            objBE.File_Type = FileUpdphoto.PostedFile.ContentType;
                            objBE.Document_Imag = bytes;
                        }
                        else
                        {
                            objCommon.ShowAlertMessage("Please Upload Valid Image File");
                            FileUpdphoto.Focus();
                            return;
                        }
                    }
                    else
                    {
                        if (ViewState["DocumentImage"].ToString() != "")
                        {
                            objBE.File_Name = ViewState["FileName"].ToString();
                            objBE.File_Type = ViewState["FileType"].ToString();
                            //objBE.Document_Imag = Convert.FromBase64String(ViewState["DocumentImage"].ToString());
                            objBE.Document_Imag = barrImg;
                        }
                    }
                }

                objBE.TVP = ddt;
                lblContentDtls.Text = txtcontent.Text;
                objBE.contentDesc = lblContentDtls.Text;
                objBE.MainMenu = ddlMainMenu.SelectedValue.Trim();
                objBE.SubMenu = ddlSubMenu.SelectedValue.Trim();
                objBE.ChildMenu = ddlChildMenu.SelectedValue.Trim();
                lblContentDtls.Text = txtcontent.Text;
                objBE.contentDesc = lblContentDtls.Text;
                objBE.UserName = UserName;
                objBE.Ip = Request.ServerVariables["REMOTE_ADDR"].ToString();
                objBE.Id = hdnUid.Value;
                objBE.Flag = "U";
                DataTable dt = new DataTable();
                dt = objDL.ContentManagment(objBE, ConnKey);
                if (dt.Rows.Count > 0)
                {
                    objCommon.ShowAlertMessage("Contents Not Updated");
                }
                else
                {
                    GridView1.DataSource = dt;
                    GridView1.DataBind();
                    objCommon.ShowAlertMessage("Details Updated Successfully");
                    btnUpdate.Visible = false;
                    btnsubmit.Visible = true;
                    txtcontent.Text = "";
                    //CreateRow();
                }
                BindContentDtls();
            }
        }
        catch (Exception ex)
        {
            ExceptionLogging.SendExcepToDB(ex, "", Request.ServerVariables["REMOTE_ADDR"].ToString());
            Response.Redirect("../Error.aspx");
        }
    }

    protected void GVEvent_RowCommand(object sender, GridViewCommandEventArgs e)
    {
        try
        {
            string path = "";
            GridViewRow gvrow = (GridViewRow)((Control)e.CommandSource).NamingContainer;
            if (e.CommandName == "Add")
            {
                ddt = CreateDt();
                foreach (GridViewRow gr in GVEvent.Rows)
                {
                    ddt.Rows.Add();
                    if (((FileUpload)gr.FindControl("UpldEventUpload")).HasFile)
                    {
                        if ((((FileUpload)gr.FindControl("UpldEventUpload")).PostedFile.ContentType != "image/jpeg" && ((FileUpload)gr.FindControl("UpldEventUpload")).PostedFile.ContentType != "image/png") && ((FileUpload)gr.FindControl("UpldEventUpload")).PostedFile.ContentType != "application/pdf")
                        {
                            objCommon.ShowAlertMessage("Please Upload Valid Image File/pdf file");
                            return;
                        }
                        Stream fs = ((FileUpload)gr.FindControl("UpldEventUpload")).PostedFile.InputStream;
                        BinaryReader br = new BinaryReader(fs); //reads the binary files  
                        Byte[] bytes = br.ReadBytes((Int32)fs.Length);
                        //if (((FileUpload)gr.FindControl("UpldEventUpload")).PostedFile.ContentLength > 6e+6)
                        //{
                        //    objCommon.ShowAlertMessage("File Size Exceeded Please upload less than 6mb size file");
                        //    return;
                        //}
                        ddt.Rows[j]["File_Name"] = Path.GetFileNameWithoutExtension(((FileUpload)gr.FindControl("UpldEventUpload")).PostedFile.FileName);
                        ddt.Rows[j]["File_Type"] = Path.GetExtension(((FileUpload)gr.FindControl("UpldEventUpload")).PostedFile.FileName);
                        ddt.Rows[j]["Document_Image"] = Convert.ToBase64String(bytes);
                    }
                    else
                    {
                        if (((Label)gr.FindControl("lblFName")).Text.Trim() != "")
                        {
                            ddt.Rows[j]["File_Name"] = ((Label)gr.FindControl("lblFName")).Text.Trim();
                            ddt.Rows[j]["File_Type"] = ((Label)gr.FindControl("lblFType")).Text.Trim();
                            ddt.Rows[j]["Document_Image"] = ((Label)gr.FindControl("lblDocumentImage")).Text.Trim();
                        }
                    }

                    j++;
                }
                //if (((FileUpload)gvrow.FindControl("UpldEventUpload")).HasFile == true || ((Label)gvrow.FindControl("lblFName")).Text != "")
                ddt.Rows.Add();
                GVEvent.DataSource = ddt;
                GVEvent.DataBind();
            }
            if (e.CommandName == "Remove")
            {
                ddt = CreateDt();
                foreach (GridViewRow gr in GVEvent.Rows)
                {
                    ddt.Rows.Add();
                    if (((FileUpload)gr.FindControl("UpldEventUpload")).HasFile)
                    {
                        if ((((FileUpload)gr.FindControl("UpldEventUpload")).PostedFile.ContentType != "image/jpeg" && ((FileUpload)gr.FindControl("UpldEventUpload")).PostedFile.ContentType != "image/png") && ((FileUpload)gr.FindControl("UpldEventUpload")).PostedFile.ContentType != "application/pdf")
                        {
                            objCommon.ShowAlertMessage("Please Upload Valid Image File/pdf file");
                            return;
                        }
                        Stream fs = ((FileUpload)gr.FindControl("UpldEventUpload")).PostedFile.InputStream;
                        BinaryReader br = new BinaryReader(fs); //reads the binary files  
                        Byte[] bytes = br.ReadBytes((Int32)fs.Length);
                        if (((FileUpload)gr.FindControl("UpldEventUpload")).PostedFile.ContentLength > 2097152)
                        {
                            objCommon.ShowAlertMessage("File Size Exceeded Please upload less than 2mb size file");
                            return;
                        }
                        ddt.Rows[j]["File_Name"] = Path.GetFileNameWithoutExtension(((FileUpload)gr.FindControl("UpldEventUpload")).PostedFile.FileName);
                        ddt.Rows[j]["File_Type"] = Path.GetExtension(((FileUpload)gr.FindControl("UpldEventUpload")).PostedFile.FileName);
                        ddt.Rows[j]["Document_Image"] = Convert.ToBase64String(bytes);
                    }
                    else
                    {
                        if (((Label)gr.FindControl("lblFName")).Text.Trim() != "")
                        {
                            ddt.Rows[j]["File_Name"] = ((Label)gr.FindControl("lblFName")).Text.Trim();
                            ddt.Rows[j]["File_Type"] = ((Label)gr.FindControl("lblFType")).Text.Trim();
                            ddt.Rows[j]["Document_Image"] = ((Label)gr.FindControl("lblDocumentImage")).Text.Trim();
                        }
                    }
                    j++;
                }
                if (ddt.Rows.Count > 0)
                {
                    //if (((Label) gvrow.FindControl("lblFName")).Text != "")
                    //{
                    //    //File.Delete(path);
                    //}
                    ddt.Rows.RemoveAt(gvrow.RowIndex);
                    if (ddt.Rows.Count == 0)
                    {
                        ddt.Rows.Add();
                    }
                    GVEvent.DataSource = ddt;
                    GVEvent.DataBind();
                }
            }
        }
        catch (Exception ex)
        {
            ExceptionLogging.SendExcepToDB(ex, Session["UsrName"].ToString(), Request.ServerVariables["REMOTE_ADDR"].ToString());
            Response.Redirect("../Error.aspx");
        }
    }
}


