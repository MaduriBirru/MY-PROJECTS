﻿using System;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Globalization;
using GAETEC_BE;
using GAETEC_DL;
using System.IO;
using System.Data;
using System.Data.SqlClient;
public partial class Event_Mst : System.Web.UI.Page
{
    CommonFuncs objCommon = new CommonFuncs();
    Admin_BE objBE = new Admin_BE();
    Admin_DL objDL = new Admin_DL();
    Events_IDU objEventBE = new Events_IDU();
    SampleSqlInjectionScreeningModule objsql = new SampleSqlInjectionScreeningModule();
    DataSet ds = new DataSet();
    
    string ConnKey;

    protected void Page_Load(object sender, EventArgs e)
    {
        if ((Request.ServerVariables["HTTP_REFERER"] == null) || (Request.ServerVariables["HTTP_REFERER"] == ""))
        {
            Response.Redirect("../Error.aspx");
        }
        else
        {
            string http_ref = Request.ServerVariables["HTTP_REFERER"].Trim();
            string http_hos = Request.ServerVariables["HTTP_HOST"].Trim();
            int len = http_hos.Length;
            if (http_ref.IndexOf(http_hos, 0) < 0)
            {
                Response.Redirect("../Error.aspx");
            }
        }
        /*KILL COOKIE & clear Caching*/
        PrevBrowCache.enforceNoCache();
        if (Session["Role"] != null && Session["AuthToken"] != null && Request.Cookies["AuthToken"] != null)
        {
            if (!Session["AuthToken"].ToString().Equals(Request.Cookies["AuthToken"].Value))
            {
                Response.Redirect("../Error.aspx");
            }
        }
        if (!IsPostBack)
        {
            inputcheck();
            BindEventDropDown();
            BindEventPhotos();
            BindEventGrid();
            EventDiv.Visible = false;
            ViewState["visible"] = false;
            random();
        }
        check();

    }

    public void inputcheck()
    {
        string url = Request.Url.ToString();
        foreach (string key in Request.QueryString)
            objsql.CheckInput(Request.QueryString[key]);
        foreach (string key in Request.Cookies)
            objsql.CheckInput(Request.Cookies[key].Value);
    }

    public void ValidChars()
    {
        foreach (string key in Request.Form)
        {
            if (!key.Contains("__"))
            {
                objsql.CheckInput(Request.Form[key]);
            }
        }
    }

    public void random()
    {
        try
        {
            string strString = "abcdefghijklmnpqrstuvwxyzABCDQEFGHIJKLMNOPQRSTUVWXYZ1234567890";
            string num = "";
            Random rm = new Random();
            for (int i = 0; i < 16; i++)
            {
                int randomcharindex = rm.Next(0, strString.Length);
                char randomchar = strString[randomcharindex];
                num += Convert.ToString(randomchar);
            }


            hf.Value = num;
            Session["ASPFIXATION2"] = num;
        }
        catch (Exception ex)
        {
            Response.Redirect("../Error.aspx");
        }
    }

    public void check()
    {
        try
        {
            string cookie_value = null;
            string session_value = null;

            cookie_value = hf.Value;
            session_value = System.Web.HttpContext.Current.Session["ASPFIXATION2"].ToString();
            if (cookie_value != session_value)
            {
                System.Web.HttpContext.Current.Session.Abandon();
                HttpContext.Current.Response.Buffer = false;
                HttpContext.Current.Response.Redirect("../Error.aspx");
            }
        }
        catch (Exception ex)
        {
            Response.Redirect("../Error.aspx");
        }
    }

    protected bool Validate()
    {

        if (string.IsNullOrEmpty(ddlEvents.SelectedValue) || ddlEvents.SelectedValue == "0")
        {
            objCommon.ShowAlertMessage("Select Event Name");
            ddlEvents.Focus();
            return false;
        }

        if (!fileupload.HasFile)
        {
            objCommon.ShowAlertMessage("Please select a file to Upload");
            fileupload.Focus();
            return false;
        }
        if (fileupload.HasFile)
        {
            string extension = Path.GetExtension(fileupload.FileName);
            extension = extension.Substring(1);
            if (extension.ToUpper() != "JPEG" && extension.ToUpper() != "JPG" && extension.ToUpper() != "PNG")
            {
                objCommon.ShowAlertMessage("Please select JPEG or JPG or PNG");
                return false;
            }
        }
        //if (string.IsNullOrEmpty(txtDescription.Text))
        //{
        //    objCommon.ShowAlertMessage("Enter Description");
        //    txtDescription.Focus();
        //    return false;
        //}
        //if (txtDescription.Text != "")
        //{
        //    SampleSqlInjectionScreeningModule obj = new SampleSqlInjectionScreeningModule();

        //    bool val;
        //    val = obj.CheckInput_new(txtDescription.Text);
        //    if (val == true)
        //    {
        //        Response.Redirect("~/Error.aspx");
        //    }


        //}

        return true;
    }

    protected void btnsubmit_Click(object sender, EventArgs e)
    {
        try
        {
            check();
            ValidChars();
            if (Validate())
            {
                var fileName = Path.GetFileName(fileupload.FileName);
                var ext = Path.GetExtension(fileupload.FileName);
                string name = Path.GetFileNameWithoutExtension(fileName);
                string myfile = name + "_" + DateTime.Now.ToString("yyyyMMddHHmmss") + ext;
                var path = Path.Combine(Server.MapPath("~/IMAP/Crop_Images"), myfile);
                fileupload.SaveAs(path);
                objBE.ImageURL = myfile;

                Stream fs = fileupload.PostedFile.InputStream;
                BinaryReader br = new BinaryReader(fs);
                Byte[] imageByte = br.ReadBytes((Int32)fs.Length);
                objBE.Event_id = ddlEvents.SelectedValue;
                objBE.Event_Desc = txtDescription.Text;
                objBE.Image = imageByte;
                objBE.File_Type = Path.GetExtension(fileupload.FileName).Substring(1);
                objBE.File_Name = Path.GetFileName(fileupload.FileName);
                objBE.RoleId = Convert.ToString(Session["Role"]);
                int i = objEventBE.InsertEventPhoto(objBE);
                if (i > 0)
                {
                    objCommon.ShowAlertMessage("Record " + btnsubmit.Text + " Successfully");
                    BindEventPhotos();
                    ResetFields();
                }
            }
        }
        catch (Exception ex)
        {
            ExceptionLogging.SendExcepToDB(ex, Session["UsrName"].ToString(), Request.ServerVariables["REMOTE_ADDR"].ToString());
            //Response.Redirect("~/Error.aspx");
        }
    }

    private void ResetFields()
    {
        ddlEvents.ClearSelection();
        txtDescription.Text = "";
        btnsubmit.Text = "Submit";
    }

    protected void BindEventPhotos()
    {
        try
        {
            DataTable dt = new DataTable();
            SqlCommand cmd = new SqlCommand("GAETEC_CM_Sp_SelectEventPhotos");
            dt = objDL.ExecuteSelect(cmd).Tables[0];
            gvdEventPhoto.DataSource = dt;
            gvdEventPhoto.DataBind();
        }
        catch (Exception ex)
        {
            ExceptionLogging.SendExcepToDB(ex, Session["UsrName"].ToString(), Request.ServerVariables["REMOTE_ADDR"].ToString());
            Response.Redirect("../Error.aspx");
        }
    }

    protected void linklinkedit_OnClick(object sender, EventArgs e)
    {
        try
        {
            btnsubmit.Text = "Update";

            ImageButton linkedit = (ImageButton)sender;
            GridViewRow gdRow = (GridViewRow)linkedit.NamingContainer;
            Label Uid = gdRow.FindControl("lblEventId") as Label;
            Label lblBindEventId = gdRow.FindControl("lblBindEventId") as Label;
            Label lblDescription = gdRow.FindControl("lblDescription") as Label;
            Label lblFileName = gdRow.FindControl("lblFileName") as Label;
            Label lblFileType = gdRow.FindControl("lblFileType") as Label;
            Label lblFileData = gdRow.FindControl("lblFileData") as Label;


            ddlEvents.SelectedValue = lblBindEventId.Text;
            txtDescription.Text = lblDescription.Text;
            hdnFileType.Value = lblFileType.Text;
            hdnFilName.Value = lblFileName.Text;
            hdnImage.Value = lblFileData.Text;
            hdnUid.Value = Uid.Text;

            //ImageUpdateImg.Visible = true;
            //ImageUpdateImg.ImageUrl = "data:image/jpg;base64," + lblImage.Text;

        }
        catch (Exception ex)
        {
            ExceptionLogging.SendExcepToDB(ex, Session["UsrName"].ToString(), Request.ServerVariables["REMOTE_ADDR"].ToString());
            Response.Redirect("../Error.aspx");
        }
    }

    protected void linkDelete_OnClick(object sender, EventArgs e)
    {
        try
        {
            ImageButton Lnkdelete = (ImageButton)sender;
            GridViewRow gdRow = (GridViewRow)Lnkdelete.NamingContainer;
            Label Uid = gdRow.FindControl("lblEventId") as Label;
            Label Imagename = gdRow.FindControl("lblImageName") as Label;
            objBE.Id = Uid.Text;
            int i = objEventBE.DeleteEventPhoto(objBE);
            if (i > 0)
            {
                objCommon.ShowAlertMessage("Record Deleted Successfully");
                ResetFields();
                BindEventPhotos();
                string FileName = Imagename.Text;
                string fullPath = Request.MapPath("~/IMAP/Crop_Images/" + FileName);

                if (System.IO.File.Exists(fullPath))
                {
                    System.IO.File.Delete(fullPath);
                }

            }
        }
        catch (Exception ex)
        {
            ExceptionLogging.SendExcepToDB(ex, Session["UsrName"].ToString(), Request.ServerVariables["REMOTE_ADDR"].ToString());
            Response.Redirect("../Error.aspx");
        }
    }

    protected void btnreset_Click1(object sender, EventArgs e)
    {
        //Cleardata();
        //bindgridview();
    }

    public DataTable GetEvents()
    {
        SqlCommand cmd = new SqlCommand("GAETEC_CM_Sp_GetEvents");
        DataTable dt = objDL.ExecuteSelect(cmd).Tables[0];
        return dt;
    }

    public void BindEventDropDown()
    {
        objCommon.BindDropDownLists(ddlEvents, GetEvents(), "EventName", "Event_id", "Select Event");
    }

    public void BindEventGrid()
    {
        gvdEvents.DataSource = GetEvents();
        gvdEvents.DataBind();
    }

    protected void btnCreateEvent_Click(object sender, EventArgs e)
    {
        if (string.IsNullOrEmpty(txtEvent.Text))
        {
            objCommon.ShowAlertMessage("Enter Event Name");
            txtEvent.Focus();
            return;
        }

        if (string.IsNullOrEmpty(txtEvent.Text))
        {
            objCommon.ShowAlertMessage("Enter Event Name");
            txtEvent.Focus();
            return;
        }

        if (!string.IsNullOrEmpty(txtEvent.Text))
        {
            SampleSqlInjectionScreeningModule obj = new SampleSqlInjectionScreeningModule();

            bool val;
            val = obj.CheckInput_new(txtEvent.Text);
            if (val == true)
            {
                Response.Redirect("../Error.aspx");
            }
            else
            {
                objBE.EventName = txtEvent.Text;
                objBE.RoleId = Convert.ToString(Session["Role"]);
                int i = objEventBE.InsertEvent(objBE);
                if (i > 0)
                {
                    objCommon.ShowAlertMessage("Record " + btnsubmit.Text + " Successfully");
                    ViewState["visible"] = false;
                    visiblefalse();
                }
            }
        }
    }

    protected void ImgEventDelete_OnClick(object sender, EventArgs e)
    {
        try
        {
            ImageButton Lnkdelete = (ImageButton)sender;
            GridViewRow gdRow = (GridViewRow)Lnkdelete.NamingContainer;
            Label Uid = gdRow.FindControl("lblEventId") as Label;
            objBE.Event_id = Uid.Text;
            int i = objEventBE.DeleteEvent(objBE);
            if (i > 0)
            {
                if (i == 547)
                {
                    objCommon.ShowAlertMessage("First delete Photos of this Event.");
                    ResetFields();
                    BindEventPhotos();
                }
                else
                {
                    objCommon.ShowAlertMessage("Record Deleted Successfully");
                    ResetFields();
                    visiblefalse();
                    ViewState["visible"] = false;
                }
            }
        }
        catch (Exception ex)
        {
            ExceptionLogging.SendExcepToDB(ex, Session["UsrName"].ToString(), Request.ServerVariables["REMOTE_ADDR"].ToString());
            Response.Redirect("../Error.aspx");
        }
    }


    protected void btnCreate_Click(object sender, EventArgs e)
    {
        EventDiv.Visible = true;
        if ((bool)ViewState["visible"] == false)
        {
            visibletrue();
            ViewState["visible"] = true;
        }
        else
        {
            ViewState["visible"] = false;
            visiblefalse();
        }
    }


    protected void visibletrue()
    {
        txtEvent.Text = "";
        lblNewEvent.Visible = true;
        Label1.Visible = true;
        txtEvent.Visible = true;
        // gvdEvents.Visible = true;
        btnCreateEvent.Visible = true;
        btnCancelevent.Visible = true;
        BindEventGrid();
        BindEventDropDown();
        BindEventPhotos();
    }

    protected void visiblefalse()
    {
        txtEvent.Text = "";
        lblNewEvent.Visible = false;
        Label1.Visible = false;
        txtEvent.Visible = false;
        // gvdEvents.Visible = false;
        btnCreateEvent.Visible = false;
        btnCancelevent.Visible = false;
        BindEventGrid();
        BindEventDropDown();
        BindEventPhotos();
    }

    protected void btnCancelevent_Click(object sender, EventArgs e)
    {
        ViewState["visible"] = false;
        visiblefalse();
    }


}