﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.IO;
using GAETEC_BE;
using GAETEC_DL;

public partial class Admin_HomeSlider : System.Web.UI.Page
{
    Admin_DL admin = new Admin_DL();
    CommonFuncs cf = new CommonFuncs();
    DataTable dt;
    Admin_BE objcn = new Admin_BE();



    protected void Page_Load(object sender, EventArgs e)
    {
        if ((Request.ServerVariables["HTTP_REFERER"] == null) || (Request.ServerVariables["HTTP_REFERER"] == ""))
        {
            Response.Redirect("../Login.aspx");
        }
        else
        {
            string http_ref = Request.ServerVariables["HTTP_REFERER"].Trim();
            string http_hos = Request.ServerVariables["HTTP_HOST"].Trim();
            int len = http_hos.Length;
            if (http_ref.IndexOf(http_hos, 0) < 0)
            {
                Response.Redirect("../Login.aspx");
            }
        }
        if (Session["Role"].ToString() == null)
        {
            Response.Redirect("../Login.aspx");
        }
        if (!IsPostBack)
        {
            try
            {
                BindGrid();
            }
            catch (Exception ex)
            {
                ExceptionLogging.SendExcepToDB(ex, Session["UsrName"].ToString(), Request.ServerVariables["REMOTE_ADDR"].ToString());
                Response.Redirect("../Error.aspx");
            }
        }
    }
    protected void BindGrid()
    {

        objcn.Action = "R";
        dt = new DataTable();

        dt = admin.InsertSliderPageImages_IUDR(objcn);

        if (dt.Rows.Count > 0)
        {
            GVslide.DataSource = dt;
            GVslide.DataBind();
        }
        else
        {
            GVslide.DataSource = null;
            GVslide.DataBind();
        }


    }
    public string GetImage(object img)
    {
        if (img != DBNull.Value)
        {
            return "data:image/jpg;base64," + Convert.ToBase64String((byte[])img);
        }
        else
        {
            return "";
        }
    }
    protected void UpdateData(object sender, EventArgs e)
    {

        try
        {
            if (FileUpload1.HasFile == false)
            {
                cf.ShowAlertMessage("Please Upload Image .JPG,.PNG,.jpg,.png,.jpeg");
                FileUpload1.Focus();

            }
            string fileNm = "", fileSize = "", fileType = "";
            byte[] content = null;
            if (FileUpload1.HasFile != null)
            {
                Stream fs = FileUpload1.PostedFile.InputStream;
                BinaryReader br = new BinaryReader(fs);
                Byte[] bytes = br.ReadBytes((Int32)fs.Length);
                string fileext = Path.GetExtension(FileUpload1.PostedFile.FileName);
                //string mime =  MimeType.GetMimeType(bytes, FileUpload1.PostedFile.FileName);
                if (fileext == ".jpg" || fileext == ".PNG" || fileext == ".png" || fileext == ".jpeg" || fileext == ".JPG")
                {
                    int len = FileUpload1.PostedFile.ContentLength;
                    if ((len / 1024) > 250000)
                    {
                        cf.ShowAlertMessage("File size is exceeded");
                        FileUpload1.Focus();
                        return;
                    }

                    string fn = Path.GetFileName(FileUpload1.PostedFile.FileName);
                    objcn.image_name = fn;
                    objcn.image_size = len.ToString();
                    objcn.image_type = fileext;
                    objcn.image_content = bytes;
                }
                else
                {
                    cf.ShowAlertMessage("Invalid file");
                    return;
                }

            }



            objcn.slnumber = lblsrid.Text;
            objcn.Action = "U";
            dt = new DataTable();
            //dt = admin.InsertSliderPageImages_IUDR(objcn);
            dt = admin.InsertSliderPageImages_IUDR(objcn);

            if (dt.Rows.Count > 0)
            {
                cf.ShowAlertMessage("Your Image Update Failed");
                BindGrid();
                txtsrno.Text = "";
                txtsrno.Visible = false;
                lblimgid.Visible = false;

            }
            else
            {
                cf.ShowAlertMessage("Your Image Updete Successusfully");
                BindGrid();
                txtsrno.Text = "";
                txtsrno.Visible = false;
                lblimgid.Visible = false;
            }

        }

        catch (Exception ex)
        {
            ExceptionLogging.SendExcepToDB(ex, Session["UsrName"].ToString(), Request.ServerVariables["REMOTE_ADDR"].ToString());
            Response.Redirect("../Error.aspx");
        }

    }
    protected void uploadData(object sender, EventArgs e)
    {
        try
        {
            if (FileUpload1.HasFile == false)
            {
                cf.ShowAlertMessage("Please Upload Image .JPG,.PNG,.jpg,.png,.jpeg");
                FileUpload1.Focus();
                lblimgid.Text = "Image ID";
                txtsrno.Visible = true;
            }

            if (FileUpload1.HasFile)
            {
                Stream fs = FileUpload1.PostedFile.InputStream;
                BinaryReader br = new BinaryReader(fs);
                Byte[] bytes = br.ReadBytes((Int32)fs.Length);
                string fileext = Path.GetExtension(FileUpload1.PostedFile.FileName);
                //string mime =  MimeType.GetMimeType(bytes, FileUpload1.PostedFile.FileName);
                if (fileext == ".jpg" || fileext == ".PNG" || fileext == ".png" || fileext == ".jpeg" || fileext == ".JPG")
                {
                    int len = FileUpload1.PostedFile.ContentLength;
                    if ((len / 1024) > 250000)
                    {
                        cf.ShowAlertMessage("File size is exceeded");
                        FileUpload1.Focus();
                        return;
                    }

                    string fn = Path.GetFileName(FileUpload1.PostedFile.FileName);

                    objcn.image_name = fn;
                    objcn.image_size = len.ToString();
                    objcn.image_type = fileext;
                    objcn.image_content = bytes;

                }
            }
            objcn.Action = "I";
            dt = new DataTable();

            dt = admin.InsertSliderPageImages_IUDR(objcn);
            if (dt.Rows.Count > 0)
            {
                cf.ShowAlertMessage("Your Image Uploaded Failed");
                BindGrid();

            }
            else
            {
                cf.ShowAlertMessage("Your Image Uploaded Successusfully");
                BindGrid();
                txtsrno.Text = "";

            }
        }
        catch (Exception ex)
        {
            ExceptionLogging.SendExcepToDB(ex, Session["UsrName"].ToString(), Request.ServerVariables["REMOTE_ADDR"].ToString());
            Response.Redirect("../Error.aspx");
        }


    }

    public void random()
    {
        try
        {
            string strString = "abcdefghijklmnpqrstuvwxyzABCDQEFGHIJKLMNOPQRSTUVWXYZ1234567890";
            string num = "";
            Random rm = new Random();
            for (int i = 0; i < 16; i++)
            {
                int randomcharindex = rm.Next(0, strString.Length);
                char randomchar = strString[randomcharindex];
                num += Convert.ToString(randomchar);
            }


            hf.Value = num;
            Session["ASPFIXATION2"] = num;
        }
        catch (Exception ex)
        {
            Response.Redirect("../Error.aspx");
        }
    }
    public void check()
    {
        try
        {
            string cookie_value = null;
            string session_value = null;

            cookie_value = hf.Value;
            session_value = System.Web.HttpContext.Current.Session["ASPFIXATION2"].ToString();
            if (cookie_value != session_value)
            {
                System.Web.HttpContext.Current.Session.Abandon();
                HttpContext.Current.Response.Buffer = false;
                HttpContext.Current.Response.Redirect("~/Error.aspx");
            }
        }
        catch (Exception ex)
        {
            Response.Redirect("../Error.aspx");
        }
    }

    protected void GVslide_RowCommand(object sender, GridViewCommandEventArgs e)
    {

        if (e.CommandName == "Dlt")
        {
            GridViewRow gvrow = (GridViewRow)((Control)e.CommandSource).NamingContainer;

            lblsrid.Text = ((Label)gvrow.FindControl("lblslno")).Text;
            objcn.slnumber = lblsrid.Text;
            objcn.Action = "D";
            dt = admin.InsertSliderPageImages_IUDR(objcn);
            if (dt.Rows.Count > 0)
            {
                cf.ShowAlertMessage("Delete Failed");
                BindGrid();
            }
            else
            {
                cf.ShowAlertMessage("Delete Successesfully");
                BindGrid();
            }
            Btn_update.Visible = false;
            Btn_Upload.Visible = true;

        }
    }
    protected void GVslide_RowCommand1(object sender, GridViewCommandEventArgs e)
    {
        if (e.CommandName == "Dlt")
        {
            GridViewRow gvrow = (GridViewRow)((Control)e.CommandSource).NamingContainer;

            lblsrid.Text = ((Label)gvrow.FindControl("lblslno")).Text;
            objcn.slnumber = lblsrid.Text;
            objcn.Action = "D";
            dt = admin.InsertSliderPageImages_IUDR(objcn);
            if (dt.Rows.Count > 0)
            {
                cf.ShowAlertMessage("Delete Failed");
                BindGrid();
            }
            else
            {
                cf.ShowAlertMessage("Delete Successesfully");
                BindGrid();
            }
            Btn_update.Visible = false;
            Btn_Upload.Visible = true;
        }
    }
}