﻿using System;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using GAETEC_BE;
using GAETEC_DL;
using System.IO;
using System.Data;
using System.Data.SqlClient;
using System.Text.RegularExpressions;


public partial class Admin_Notifications : System.Web.UI.Page
{

    CommonFuncs objCommon = new CommonFuncs();
    Admin_BE objBE = new Admin_BE();
    Admin_DL objDL = new Admin_DL();
    SampleSqlInjectionScreeningModule objsql = new SampleSqlInjectionScreeningModule();
    DataSet ds = new DataSet();
    string ConnKey;
    protected void Page_Load(object sender, EventArgs e)
    {
        if ((Request.ServerVariables["HTTP_REFERER"] == null) || (Request.ServerVariables["HTTP_REFERER"] == ""))
        {
            Response.Redirect("../Error.aspx");
        }
        else
        {
            string http_ref = Request.ServerVariables["HTTP_REFERER"].Trim();
            string http_hos = Request.ServerVariables["HTTP_HOST"].Trim();
            int len = http_hos.Length;
            if (http_ref.IndexOf(http_hos, 0) < 0)
            {
                Response.Redirect("../Error.aspx");
            }
        }
        ConnKey = Session["ConnKey"].ToString();
        /*KILL COOKIE & clear Caching*/
        PrevBrowCache.enforceNoCache();
        if (Session["Role"] != null && Session["AuthToken"] != null && Request.Cookies["AuthToken"] != null)
        {
            if (!Session["AuthToken"].ToString().Equals(Request.Cookies["AuthToken"].Value))
            {
                Response.Redirect("../Error.aspx");
            }
        }

        if (!IsPostBack)
        {
            inputcheck();
            random();
            BindNotifications();
        }
    }
    public void check()
    {
        try
        {
            string cookie_value = null;
            string session_value = null;
            //cookie_value = System.Web.HttpContext.Current.Request.Cookies["ASPFIXATION2"].Value;
            cookie_value = hf.Value; //Session["hf"].ToString();
            session_value = System.Web.HttpContext.Current.Session["ASPFIXATION2"].ToString();
            if (cookie_value != session_value)
            {
                System.Web.HttpContext.Current.Session.Abandon();
                HttpContext.Current.Response.Buffer = false;
                HttpContext.Current.Response.Redirect("~/Error.aspx");
            }
        }
        catch (Exception ex)
        {
            Response.Redirect("../Error.aspx");
        }
    }
    public void inputcheck()
    {
        string url = Request.Url.ToString();
        foreach (string key in Request.QueryString)
            objsql.CheckInput(Request.QueryString[key]);
        foreach (string key in Request.Cookies)
            objsql.CheckInput(Request.Cookies[key].Value);
    }
    public void random()
    {
        try
        {
            string strString = "abcdefghijklmnpqrstuvwxyzABCDQEFGHIJKLMNOPQRSTUVWXYZ1234567890";
            string num = "";
            Random rm = new Random();
            for (int i = 0; i < 16; i++)
            {
                int randomcharindex = rm.Next(0, strString.Length);
                char randomchar = strString[randomcharindex];
                num += Convert.ToString(randomchar);
            }
            hf.Value = num;
            Session["ASPFIXATION2"] = num;
        }
        catch (Exception ex)
        {
            Response.Redirect("../Error.aspx");
        }
    }
    public void ValidChars()
    {
        foreach (string key in Request.Form)
        {
            if (!key.Contains("__"))
            {
                objsql.CheckInput(Request.Form[key]);
            }
        }
    }
    protected void btnsubmit_Click(object sender, EventArgs e)
    {
        try
        {
            check();
            ValidChars();
            if (Validatefun())
            {
                objBE.From_Dt = txtValidFrom.Text;
                objBE.To_Dt = txtValidTo.Text;
                objBE.Notification_Title = txtnotificationtitle.Text;
                objBE.RoleId = Session["Role"].ToString();
                if (fileupload.HasFile)
                {
                    Stream fs = fileupload.PostedFile.InputStream;
                    BinaryReader br = new BinaryReader(fs);
                    Byte[] bytes = br.ReadBytes((Int32)fs.Length);
                    string mime = MimeType.GetMimeType(bytes, fileupload.PostedFile.FileName);

                    //Set the contenttype based on File Extension
                    if (mime == "application/pdf")
                    {
                        int len = fileupload.PostedFile.ContentLength;
                        if ((len / 1024) > 5120)
                        {
                            objCommon.ShowAlertMessage("File size is exceeded");
                            fileupload.Focus();
                            return;
                        }
                        string fileext = Path.GetExtension(fileupload.PostedFile.FileName);
                        string filname = Path.GetFileName(fileupload.PostedFile.FileName);
                        objBE.Document_Imag = bytes;
                        objBE.File_Name = filname;
                        objBE.File_Type = fileext;
                    }
                    else
                    {
                        objCommon.ShowAlertMessage("Invalid File");
                        return;
                    }
                }
                objBE.RoleId = Session["Role"].ToString();
                objBE.Flag = "I";
                DataTable dt = new DataTable();
                dt = objDL.Notifications_IUDR(objBE, ConnKey);
                if (dt.Rows.Count > 0)
                {
                    objCommon.ShowAlertMessage("Record " + btnsubmit.Text + " Successfully");
                    BindNotifications();
                    ResetFields();
                }
            }
        }
        catch (Exception ex)
        {
            ExceptionLogging.SendExcepToDB(ex, Session["UsrName"].ToString(), Request.ServerVariables["REMOTE_ADDR"].ToString());
            Response.Redirect("../Error.aspx");
        }
    }

    protected void linklinkedit_OnClick(object sender, EventArgs e)
    {
        try
        {
            LinkButton Lnkdelete = (LinkButton)sender;
            GridViewRow gdRow = (GridViewRow)Lnkdelete.NamingContainer;
            Label Uid = gdRow.FindControl("lbluid") as Label;
            Label lblNotification = gdRow.FindControl("lblNotificationTitle") as Label;
            Label lblVaidFrom = gdRow.FindControl("lblValidFrom") as Label;
            Label lblValidTo = gdRow.FindControl("lblValidTo") as Label;
            Label lblDocumentImage = gdRow.FindControl("lblDocumentImage") as Label;
            Label lblFileName = gdRow.FindControl("lblFileName") as Label;
            Label lblFileType = gdRow.FindControl("lblFileType") as Label;

            txtnotificationtitle.Text = lblNotification.Text;
            txtValidFrom.Text = lblVaidFrom.Text;
            txtValidTo.Text = lblValidTo.Text;
            //hdnUid.Value = Uid.Text;
            //hdnImage.Value = lblDocumentImage.Text;
            //hdnFileName.Value = lblFileName.Text;
            //hdnFileType.Value = lblFileType.Text;
            ViewState["Id"] = Uid.Text;
            ViewState["DocumentImage"] = lblDocumentImage.Text;
            ViewState["FileName"] = lblFileName.Text;
            ViewState["FileType"] = lblFileType.Text;
            btnsubmit.Visible = false;
            btnUpdate.Visible = true;
        }
        catch (Exception ex)
        {
            ExceptionLogging.SendExcepToDB(ex, Session["UsrName"].ToString(), Request.ServerVariables["REMOTE_ADDR"].ToString());
            Response.Redirect("../Error.aspx");
        }
    }

    protected void linkDelete_OnClick(object sender, EventArgs e)
    {
        try
        {
            LinkButton Lnkdelete = (LinkButton)sender;
            GridViewRow gdRow = (GridViewRow)Lnkdelete.NamingContainer;
            Label Uid = gdRow.FindControl("lbluid") as Label;
            objBE.Id = Uid.Text;
            objBE.Flag = "D";
            DataTable dt = objDL.Notifications_IUDR(objBE, ConnKey);
            if (dt.Rows.Count > 0)
            {
                objCommon.ShowAlertMessage("Record Deleted Successfully");
                BindNotifications();
                ResetFields();
            }
            else
            {
                objCommon.ShowAlertMessage("Record Unable to Delete");
            }
        }
        catch (Exception ex)
        {
            ExceptionLogging.SendExcepToDB(ex, Session["UsrName"].ToString(), Request.ServerVariables["REMOTE_ADDR"].ToString());
            Response.Redirect("../Error.aspx");
        }
    }

    public void BindNotifications()
    {
        try
        {
            objBE.Flag = "R";
            DataTable dt = objDL.Notifications_IUDR(objBE, ConnKey);
            if (dt.Rows.Count > 0)
            {
                gvNotification.Visible = true;
                gvNotification.DataSource = dt;
                gvNotification.DataBind();
            }
            else
            {
                gvNotification.Visible = false;
                objCommon.ShowAlertMessage("No Data Found");
            }
        }
        catch (Exception ex)
        {
            ExceptionLogging.SendExcepToDB(ex, Session["UsrName"].ToString(), Request.ServerVariables["REMOTE_ADDR"].ToString());
            // Response.Redirect("../Error.aspx");
        }
    }

    protected bool Validatefun()
    {
        if (txtnotificationtitle.Text == "")
        {
            objCommon.ShowAlertMessage("Enter Notification Title");
            txtnotificationtitle.Focus();
            return false;
        }
        if (txtnotificationtitle.Text != "")
        {
            SampleSqlInjectionScreeningModule obj = new SampleSqlInjectionScreeningModule();
            bool val;
            val = obj.CheckInput_new(txtnotificationtitle.Text);
            if (val == true)
            {
                Response.Redirect("../Error.aspx");
            }
        }
        if (txtValidFrom.Text == "")
        {
            objCommon.ShowAlertMessage("Enter Valid From Date");
            txtValidFrom.Focus();
            return false;
        }
        if (txtValidFrom.Text != "")
        {
            SampleSqlInjectionScreeningModule obj = new SampleSqlInjectionScreeningModule();
            bool val;
            val = obj.CheckInput_new(txtValidFrom.Text);
            if (val == true)
            {
                Response.Redirect("../Error.aspx");
            }
        }
        if (txtValidTo.Text == "")
        {
            objCommon.ShowAlertMessage("Enter Valid To Date ");
            txtValidTo.Focus();
            return false;
        }
        if (txtValidTo.Text != "")
        {
            SampleSqlInjectionScreeningModule obj = new SampleSqlInjectionScreeningModule();
            bool val;
            val = obj.CheckInput_new(txtValidTo.Text);
            if (val == true)
            {
                Response.Redirect("../Error.aspx");
            }
        }

        //if (string.IsNullOrEmpty(hdnImage.Value))
        //{
        //    if (fileupload.HasFile)
        //    {
        //        string extension = Path.GetExtension(fileupload.FileName);
        //        extension = extension.Substring(1);
        //        if (extension.ToUpper() != "PDF")
        //        {
        //            objCommon.ShowAlertMessage("Please select PDF");
        //            return false;
        //        }
        //    }
        //}
        //if (txtValidFrom.Text != "" && txtValidTo.Text != "")
        //{
        //    //DateTime Fromdate = DateTime.ParseExact(this.txtValidFrom.Text, "dd/MM/yyyy", null);
        //    //DateTime Todate = DateTime.ParseExact(this.txtValidTo.Text, "dd/MM/yyyy", null);
        //    if (Convert.ToDateTime(txtValidTo.Text) < Convert.ToDateTime(txtValidFrom.Text))
        //    {
        //        objCommon.ShowAlertMessage("Valid To Date Cannot be less than From Date");
        //    }
        //}
        return true;
    }

    protected void View(object sender, EventArgs e)
    {
        int id = int.Parse((sender as LinkButton).CommandArgument);
        objBE.Flag = "V";
        objBE.Id = id.ToString();
        DataTable dt = objDL.Notifications_IUDR(objBE, ConnKey);
        if (dt.Rows.Count > 0)
        {
            string img = Convert.ToBase64String((byte[])dt.Rows[0]["Document_Image"]);

            if (!string.IsNullOrEmpty(img))
            {
                Response.Clear();
                Response.Buffer = true;
                Response.ContentType = "application/" + dt.Rows[0]["File_Type"].ToString();
                Response.AddHeader("content-disposition", "attachement;filename=" + dt.Rows[0]["File_Name"].ToString() + "." + dt.Rows[0]["File_Type"].ToString()); // to open file prompt Box open or Save file  
                Response.Charset = "";
                Response.Cache.SetCacheability(HttpCacheability.NoCache);
                Response.BinaryWrite((byte[])dt.Rows[0]["Document_Image"]);
                Response.End();
            }
        }
    }

    protected void ResetFields()
    {
        txtnotificationtitle.Text = string.Empty;
        txtValidFrom.Text = string.Empty;
        txtValidTo.Text = string.Empty;
        //hdnUid.Value = "";
        //hdnImage.Value = "";
        //hdnFileName.Value = "";
        //hdnFileType.Value = "";
    }

    protected void gvNotification_RowDataBound(object sender, GridViewRowEventArgs e)
    {
        if (e.Row.RowType == DataControlRowType.DataRow)
        {
            Label lblDocumentImage = (Label)e.Row.FindControl("lblDocumentImage");
            if (string.IsNullOrEmpty(lblDocumentImage.Text))
            {
                LinkButton lnkView = (LinkButton)e.Row.FindControl("lnkView");
                Label lblDocument = (Label)e.Row.FindControl("lblDocument");
                lblDocument.Visible = true;
                lblDocument.Text = "No Document";
                lnkView.Visible = false;
            }
        }
    }

    protected void btnUpdate_Click(object sender, EventArgs e)
    {
        try
        {
            ValidChars();
            if (Validatefun())
            {
                //Stream fs = fileupload.PostedFile.InputStream;
                //BinaryReader br = new BinaryReader(fs); //reads the binary files  
                //Byte[] imageByte = br.ReadBytes((Int32)fs.Length);
                objBE.From_Dt = txtValidFrom.Text;
                objBE.To_Dt = txtValidTo.Text;
                objBE.Notification_Title = txtnotificationtitle.Text;
                // objBE.Document_Imag = imageByte;
                // objBE.File_Type = Path.GetExtension(fileupload.FileName).Substring(1);
                objBE.RoleId = Session["Role"].ToString();
                // objBE.File_Name = Path.GetFileNameWithoutExtension(fileupload.FileName);

                //UploadImage and Document
                //if (!string.IsNullOrEmpty(hdnImage.Value))
                //{
                //    objBE.Document_Imag = Convert.FromBase64String(hdnImage.Value);
                //    objBE.File_Name = hdnFileName.Value;
                //    objBE.File_Type = hdnFileType.Value;
                //}
                //else
                //{
                if (fileupload.HasFile)
                {
                    Stream fs = fileupload.PostedFile.InputStream;
                    BinaryReader br = new BinaryReader(fs);
                    Byte[] bytes = br.ReadBytes((Int32)fs.Length);
                    string mime = MimeType.GetMimeType(bytes, fileupload.PostedFile.FileName);
                    string fileext = Path.GetExtension(fileupload.PostedFile.FileName);
                    string filname = Path.GetFileName(fileupload.PostedFile.FileName);
                    string filename = fileupload.PostedFile.FileName;
                    string contenttype = fileupload.PostedFile.ContentType;

                    var regex = new Regex(@"^[[\w,\s-_]{1,100}\.[A-Za-z]{3}$");
                    // var validate_filename = Regex.Match(regex, filename, RegexOptions.IgnoreCase);
                    if (!regex.IsMatch(filename))
                    {
                        objCommon.ShowAlertMessage("Please Select Valid PDF File or Check File Name is Valid");
                        return;
                    }
                    if (contenttype != "application/pdf")
                    {
                        objCommon.ShowAlertMessage("Please Select Valid PDF File.");
                        return;
                    }


                    //Set the contenttype based on File Extension
                    if (mime == "application/pdf")
                    {
                        int len = fileupload.PostedFile.ContentLength;
                        if ((len / 1024) > 5120)
                        {
                            objCommon.ShowAlertMessage("File size is exceeded");
                            fileupload.Focus();
                            return;
                        }

                        objBE.File_Name = filname;
                        objBE.File_Type = fileext;

                        objBE.Document_Imag = bytes;
                    }
                    else
                    {
                        objCommon.ShowAlertMessage("Please Select Only Pdf files.");
                        return;
                    }
                }
                else
                {
                    if (ViewState["DocumentImage"].ToString() != "" && string.IsNullOrEmpty(ViewState["FileName"].ToString()))
                    {

                        objBE.File_Name = ViewState["FileName"].ToString();
                        objBE.File_Type = ViewState["FileType"].ToString();
                    }
                    else
                    {
                        objCommon.ShowAlertMessage("Please Upload Pdf files.");
                        return;
                    }
                }
            }
            objBE.RoleId = Session["Role"].ToString();
            //objBE.Id = hdnUid.Value;
            objBE.Id = ViewState["Id"].ToString();
            DataTable dt = new DataTable();
            objBE.Flag = "U";
            dt = objDL.Notifications_IUDR(objBE, ConnKey);
            ResetFields();
            if (dt.Rows.Count > 0)
            {
                BindNotifications();
                objCommon.ShowAlertMessage("Data Updated Successfully");
                ResetFields();
                btnsubmit.Visible = true;
                btnUpdate.Visible = false;
            }
        }
        catch (Exception ex)
        {
            ExceptionLogging.SendExcepToDB(ex, Session["UsrName"].ToString(), Request.ServerVariables["REMOTE_ADDR"].ToString());
            Response.Redirect("../Error.aspx");
        }
    }
}