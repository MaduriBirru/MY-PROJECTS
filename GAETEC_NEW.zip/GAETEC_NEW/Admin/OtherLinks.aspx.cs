﻿using System;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using GAETEC_BE;
using GAETEC_DL;
using System.IO;
using System.Data;
using System.Data.SqlClient;


public partial class OtherLinks : System.Web.UI.Page
{

    CommonFuncs objCommon = new CommonFuncs();
    Admin_BE objBE = new Admin_BE();
    Admin_DL objDL = new Admin_DL();
    SampleSqlInjectionScreeningModule objsql = new SampleSqlInjectionScreeningModule();
    DataTable dt;

    protected void Page_Load(object sender, EventArgs e)
    {
        if ((Request.ServerVariables["HTTP_REFERER"] == null) || (Request.ServerVariables["HTTP_REFERER"] == ""))
        {
            Response.Redirect("../Error.aspx");
        }
        else
        {
            string http_ref = Request.ServerVariables["HTTP_REFERER"].Trim();
            string http_hos = Request.ServerVariables["HTTP_HOST"].Trim();
            int len = http_hos.Length;
            if (http_ref.IndexOf(http_hos, 0) < 0)
            {
                Response.Redirect("../Error.aspx", false);
            }
        }
        /*KILL COOKIE & clear Caching*/
        PrevBrowCache.enforceNoCache();
        if (Session["Role"] != null && Session["AuthToken"] != null && Request.Cookies["AuthToken"] != null)
        {
            if (!Session["AuthToken"].ToString().Equals(Request.Cookies["AuthToken"].Value))
            {
                Response.Redirect("../Error.aspx", false);
            }
        }

        if (!IsPostBack)
        {
            random();
            BindGrid();
        }
        inputcheck();
    }
    public void inputcheck()
    {
        string url = Request.Url.ToString();
        foreach (string key in Request.QueryString)
            objsql.CheckInput(Request.QueryString[key]);
        foreach (string key in Request.Cookies)
            objsql.CheckInput(Request.Cookies[key].Value);
    }

    public void ValidChars()
    {
        foreach (string key in Request.Form)
        {
            if (!key.Contains("__"))
            {
                objsql.CheckInput(Request.Form[key]);
            }
        }
    }
    public void random()
    {
        try
        {
            string strString = "abcdefghijklmnpqrstuvwxyzABCDQEFGHIJKLMNOPQRSTUVWXYZ1234567890";
            string num = "";
            Random rm = new Random();
            for (int i = 0; i < 16; i++)
            {
                int randomcharindex = rm.Next(0, strString.Length);
                char randomchar = strString[randomcharindex];
                num += Convert.ToString(randomchar);
            }

            Response.Cookies.Add(new HttpCookie("ASPFIXATION2", num));
            hf.Value = num;
            Session["ASPFIXATION2"] = num;
        }
        catch (Exception ex)
        {
            Response.Redirect("../Error.aspx", false);
        }
    }

    public void BindGrid()
    {
        try
        {
            dt = new DataTable();
            objBE.Flag = "R";
            dt = objDL.OtherLinks(objBE);
            if (dt.Rows.Count > 0)
            {
                GridView1.Visible = true;
                GridView1.DataSource = dt;
                GridView1.DataBind();
            }
            else
            {
                GridView1.Visible = false;
                objCommon.ShowAlertMessage("No Data Found");
            }
        }
        catch (Exception ex)
        {
            ExceptionLogging.SendExcepToDB(ex, Session["UsrName"].ToString(), Request.ServerVariables["REMOTE_ADDR"].ToString());
            Response.Redirect("../Error.aspx");
        }
    }

    protected void linklinkedit_OnClick(object sender, EventArgs e)
    {
        try
        {
            btnUpdate.Visible = true;
            LinkButton Lnkdelete = (LinkButton)sender;
            GridViewRow gdRow = (GridViewRow)Lnkdelete.NamingContainer;
            Label Id = gdRow.FindControl("lblid") as Label;
            Label lblDtls = gdRow.FindControl("lblDtls") as Label;
            Label lblDesc = gdRow.FindControl("lblDesc") as Label;
            txtContentDtls.Text = lblDtls.Text;
            txtDescription.Text = lblDesc.Text;
            hdnUid.Value = Id.Text;
            btnsubmit.Visible = false;
            btnUpdate.Visible = true;

        }
        catch (Exception ex)
        {
            ExceptionLogging.SendExcepToDB(ex, Session["UsrName"].ToString(), Request.ServerVariables["REMOTE_ADDR"].ToString());
            Response.Redirect("../Error.aspx");
        }
    }

    protected bool Validatefun()
    {
        if (txtContentDtls.Text == "")
        {
            objCommon.ShowAlertMessage("Enter Link");
            txtContentDtls.Focus();
            return false;
        }

        return true;
    }

    protected void btnUpdate_Click(object sender, EventArgs e)
    {
        try
        {
            check();
            if (Validatefun())
            {
                objBE.Id = hdnUid.Value;
                objBE.contentDesc = txtDescription.Text;
                lblContentDtls.Text = txtContentDtls.Text;
                objBE.VideoURL = lblContentDtls.Text;
                objBE.Flag = "U";
                objBE.Ip = HttpContext.Current.Request.UserHostAddress;
                dt = new DataTable();
                dt = objDL.OtherLinks(objBE);
                if (dt.Rows.Count > 0)
                {
                    objCommon.ShowAlertMessage(dt.Rows[0][0].ToString());
                    txtContentDtls.Text = "";
                    txtDescription.Text = "";
                    btnUpdate.Visible = false;
                   
                }
                else
                {
                    objCommon.ShowAlertMessage("Record Unable to Update");
                    btnUpdate.Visible = true;
                }
                BindGrid();
               
            }
        }
        catch (Exception ex)
        {
            ExceptionLogging.SendExcepToDB(ex, Session["UsrName"].ToString(), Request.ServerVariables["REMOTE_ADDR"].ToString());
            Response.Redirect("../Error.aspx", false);
        }
    }
    public void check()
    {
        try
        {
            string cookie_value = null;
            string session_value = null;
            //cookie_value = System.Web.HttpContext.Current.Request.Cookies["ASPFIXATION2"].Value;
            cookie_value = hf.Value;
            session_value = System.Web.HttpContext.Current.Session["ASPFIXATION2"].ToString();
            if (cookie_value != session_value)
            {
                System.Web.HttpContext.Current.Session.Abandon();
                HttpContext.Current.Response.Buffer = false;
                HttpContext.Current.Response.Redirect("~/Error.aspx");
            }
        }
        catch (Exception ex)
        {
            Response.Redirect("../Error.aspx");
        }
    }
    protected void btnsubmit_Click(object sender, EventArgs e)
    {
        try
        {
            check();
            if (Validatefun())
            {
                objBE.contentDesc = txtDescription.Text;
                lblContentDtls.Text = txtContentDtls.Text;
                objBE.VideoURL = lblContentDtls.Text;
                objBE.UserName = Session["UsrName"].ToString();
                objBE.Flag = "I";
                objBE.Ip = HttpContext.Current.Request.UserHostAddress;
                dt = new DataTable();
                dt = objDL.OtherLinks(objBE);
                if (dt.Rows.Count > 0)
                {
                    objCommon.ShowAlertMessage(dt.Rows[0][0].ToString());
                    txtContentDtls.Text = "";
                    txtDescription.Text = "";
                    BindGrid();
                    
                }
                else
                {
                    objCommon.ShowAlertMessage("Record Not Inserted");
                }
            }
        }
        catch (Exception ex)
        {
            ExceptionLogging.SendExcepToDB(ex, Session["UsrName"].ToString(), Request.ServerVariables["REMOTE_ADDR"].ToString());
            //Response.Redirect("../Error.aspx", false);
        }
    }

    protected void linkDelete_OnClick(object sender, EventArgs e)
    {
        try
        {
            LinkButton Lnkdelete = (LinkButton)sender;
            GridViewRow gdRow = (GridViewRow)Lnkdelete.NamingContainer;
            Label Id = gdRow.FindControl("lblid") as Label;
            objBE.Id = Id.Text;
            dt = new DataTable();
            objBE.Flag = "D";
            dt = objDL.OtherLinks(objBE);
            if (dt.Rows.Count > 0)
            {
                objCommon.ShowAlertMessage(dt.Rows[0][0].ToString());
            }
            else
            {
                objCommon.ShowAlertMessage("Record Unable to Delete");
               
            }
            BindGrid();
        }
        catch (Exception ex)
        {
            ExceptionLogging.SendExcepToDB(ex, Session["UsrName"].ToString(), Request.ServerVariables["REMOTE_ADDR"].ToString());
            Response.Redirect("../Error.aspx", false);
        }
    }

}