﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.IO;
using System.Data.SqlClient;
using GAETEC_BE;
using GAETEC_DL;

public partial class VideoGallery : System.Web.UI.Page
{

    CommonFuncs objCommon = new CommonFuncs();
    Admin_BE objBE = new Admin_BE();
    Admin_DL objDL = new Admin_DL();
    SampleSqlInjectionScreeningModule objsql = new SampleSqlInjectionScreeningModule();
    DataSet ds = new DataSet();
    protected void Page_Load(object sender, EventArgs e)
    {

        if ((Request.ServerVariables["HTTP_REFERER"] == null) || (Request.ServerVariables["HTTP_REFERER"] == ""))
        {
            Response.Redirect("../Error.aspx");
        }
        else
        {
            string http_ref = Request.ServerVariables["HTTP_REFERER"].Trim();
            string http_hos = Request.ServerVariables["HTTP_HOST"].Trim();
            int len = http_hos.Length;
            if (http_ref.IndexOf(http_hos, 0) < 0)
            {
                Response.Redirect("../Error.aspx");
            }
        }
        /*KILL COOKIE & clear Caching*/
        PrevBrowCache.enforceNoCache();
        if (Session["Role"] != null && Session["AuthToken"] != null && Request.Cookies["AuthToken"] != null)
        {
            if (!Session["AuthToken"].ToString().Equals(Request.Cookies["AuthToken"].Value))
            {
                Response.Redirect("../Error.aspx");
            }
        }
        if (!IsPostBack)
        {
            random();
            BindGrid();

        }
        inputcheck();
    }



    public void check()
    {
        try
        {
            string cookie_value = null;
            string session_value = null;
            //cookie_value = System.Web.HttpContext.Current.Request.Cookies["ASPFIXATION2"].Value;
            cookie_value = hf.Value;
            session_value = System.Web.HttpContext.Current.Session["ASPFIXATION2"].ToString();
            if (cookie_value != session_value)
            {
                System.Web.HttpContext.Current.Session.Abandon();
                HttpContext.Current.Response.Buffer = false;
                HttpContext.Current.Response.Redirect("../Error.aspx");
            }
        }
        catch (Exception ex)
        {
            Response.Redirect("../Error.aspx");
        }
    }
    public void inputcheck()
    {
        string url = Request.Url.ToString();
        foreach (string key in Request.QueryString)
            objsql.CheckInput(Request.QueryString[key]);
        foreach (string key in Request.Cookies)
            objsql.CheckInput(Request.Cookies[key].Value);
    }

    public void ValidChars()
    {
        foreach (string key in Request.Form)
        {
            if (!key.Contains("__"))
            {
                objsql.CheckInput(Request.Form[key]);
            }
        }
    }
    protected void BindGrid()
    {
        try
        {
            DataTable dt = new DataTable();
            objBE.Flag = "R";
            dt = objDL.VideoGallery_IUDR(objBE);
            if (dt.Rows.Count > 0)
            {

                GvVideoGallery.DataSource = dt;
                GvVideoGallery.DataBind();
                GvVideoGallery.Visible = true;

            }
            else
            {
                GvVideoGallery.Visible = false;

            }
        }
        catch (Exception ex)
        {
            ExceptionLogging.SendExcepToDB(ex, Session["UsrName"].ToString(), Request.ServerVariables["REMOTE_ADDR"].ToString());
            Response.Redirect("../Error.aspx");
        }
    }

    public void random()
    {
        try
        {
            string strString = "abcdefghijklmnpqrstuvwxyzABCDQEFGHIJKLMNOPQRSTUVWXYZ1234567890";
            string num = "";
            Random rm = new Random();
            for (int i = 0; i < 16; i++)
            {
                int randomcharindex = rm.Next(0, strString.Length);
                char randomchar = strString[randomcharindex];
                num += Convert.ToString(randomchar);
            }
            hf.Value = num;
            Session["ASPFIXATION2"] = num;
        }
        catch (Exception ex)
        {
            Response.Redirect("../Error.aspx");
        }
    }

    protected bool Validatefun()
    {

        if (string.IsNullOrEmpty(hdnImage.Value))
        {
            if (!fileupload.HasFile)
            {
                objCommon.ShowAlertMessage("Please select a file to Upload");
                fileupload.Focus();
                return false;
            }
            if (fileupload.HasFile)
            {
                string extension = Path.GetExtension(fileupload.FileName);
                extension = extension.Substring(1);
                if (extension.ToUpper() == "MP4" && extension.ToUpper() != "WMV" && extension.ToUpper() != "OGV")
                {
                    if (fileupload.FileContent.Length / 1024 > 10240)
                    {
                        objCommon.ShowAlertMessage("File size is exceeded");
                        return false;
                    }
                }
                else
                {
                    objCommon.ShowAlertMessage("Please select only Video Files");
                    return false;
                }
            }
        }
        return true;
    }

    protected void btnsubmit_Click(object sender, EventArgs e)
    {
        try
        {
            check();
            ValidChars();
            if (Validatefun())
            {
                if (fileupload != null)
                {
                    var fileName = Path.GetFileName(fileupload.FileName);
                    var ext = Path.GetExtension(fileupload.FileName);
                    string name = Path.GetFileNameWithoutExtension(fileName);
                    string myfile = name + "_" + DateTime.Now.ToString("yyyyMMddHHmmss") + ext;
                    var path = Path.Combine(Server.MapPath("~/IMAP/Crop_Images"), myfile);
                    fileupload.SaveAs(path);
                    objBE.VideoName = myfile;
                    objBE.VideoURL = path;
                    objBE.Flag = "I";
                    DataTable dt = new DataTable();
                    dt = objDL.VideoGallery_IUDR(objBE);
                    if (dt.Rows.Count > 0)
                    {
                        objCommon.ShowAlertMessage(dt.Rows[0][0].ToString());
                    }
                    else
                    {
                        objCommon.ShowAlertMessage("Record Not Saved");

                    }
                    BindGrid();
                }
            }

        }
        catch (Exception ex)
        {
            ExceptionLogging.SendExcepToDB(ex, "", Request.ServerVariables["REMOTE_ADDR"].ToString());
            // Response.Redirect("~/Error.aspx");
        }
    }

    protected void linkDelete_OnClick(object sender, EventArgs e)
    {
        try
        {
            LinkButton Lnkdelete = (LinkButton)sender;
            GridViewRow gdRow = (GridViewRow)Lnkdelete.NamingContainer;
            Label Id = gdRow.FindControl("lbluid") as Label;
            Label VideoName = gdRow.FindControl("lblVideoName") as Label;
            objBE.Id = Id.Text;
            objBE.VideoName = VideoName.Text;
            objBE.Flag = "D";
            DataTable dt = objDL.VideoGallery_IUDR(objBE);
            if (dt.Rows.Count > 0)
            {
                string FileName = VideoName.Text;
                string fullPath = Request.MapPath("~/IMAP/Crop_Images/" + FileName);
                if (System.IO.File.Exists(fullPath))
                {
                    System.IO.File.Delete(fullPath);
                }

            }
            else
            {
                objCommon.ShowAlertMessage("Record Unable to Delete");

            }
            BindGrid();
        }
        catch (Exception ex)
        {
            ExceptionLogging.SendExcepToDB(ex, Session["UsrName"].ToString(), Request.ServerVariables["REMOTE_ADDR"].ToString());
            Response.Redirect("../Error.aspx");
        }
    }
}