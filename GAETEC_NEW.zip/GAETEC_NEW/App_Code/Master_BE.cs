﻿public class Master_BE
{
    public Master_BE()
    {
    }
}