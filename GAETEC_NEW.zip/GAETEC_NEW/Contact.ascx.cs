﻿using System;
using System.Data;
using System.Collections.Generic;
using System.Linq;
using System.Data.SqlClient;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using GAETEC_BE;
using GAETEC_DL;
using System.Configuration;
using System.Globalization;

public partial class GAETEC_NEW_Contact : System.Web.UI.UserControl
{
   Admin_BE Objbe = new Admin_BE();
    DataSet ds = new DataSet();
    CommonFuncs objcommon = new CommonFuncs();
    Admin_DL objDl = new Admin_DL();
    SampleSqlInjectionScreeningModule objsql = new SampleSqlInjectionScreeningModule();
    string Connkey = ConfigurationManager.ConnectionStrings["ConnGAETEC"].ConnectionString;

    protected void Page_Load(object sender, EventArgs e)
    {
        Page.MaintainScrollPositionOnPostBack = true;
        if (!IsPostBack)
        {

            GetHitCount();


        }
    }

            
    public void inputcheck()
    {
        string url = Request.Url.ToString();
        foreach (string key in Request.QueryString)
            objsql.CheckInput(Request.QueryString[key]);
        foreach (string key in Request.Cookies)
            objsql.CheckInput(Request.Cookies[key].Value);
    }

             public void GetHitCount()
    {
        try
        {
            DataTable dt = new DataTable();
            dt = objDl.GetHitcount();
            if (dt.Rows.Count > 0)
            {
                lblvistno.Text = Convert.ToInt64(dt.Rows[0]["HitCount"]).ToString("N0", new CultureInfo("en-IN"));
            }
        }
        catch (Exception ex)
        {
            ExceptionLogging.SendExcepToDB(ex, "GetHitCount", Request.ServerVariables["REMOTE_ADDR"].ToString());
            Response.Redirect("~/Error.aspx");
        }
    }


}