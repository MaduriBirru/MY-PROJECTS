﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Configuration;
using GAETEC_BE;
using GAETEC_DL;

public partial class ContentData : System.Web.UI.Page
{
    CommonFuncs objCommon = new CommonFuncs();
    Admin_BE objBE = new Admin_BE();
    Admin_DL objDL = new Admin_DL();
    DataTable dt = new DataTable();
    SampleSqlInjectionScreeningModule objsql = new SampleSqlInjectionScreeningModule();
    SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["ConnGAETEC"].ConnectionString);

    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            inputcheck();

            //if (Request.Url.Query != "")
            //    if (!UrlTampering.EnsureURLNotTampereding(
            //    Request.Url.Segments[Request.Url.Segments.Length + 1] +
            //    Request.Url.Query.Substring(0, Request.Url.Query.LastIndexOf("&Digest=")),
            //    Request.QueryString["Digest"]))
            //    {
            //        Response.Redirect("~/Error.aspx");
            //    }

            // BindData();
            if (Request.QueryString["MainMenu"] != null & Request.QueryString["SubMenuId"] == null & Request.QueryString["ChildMenuId"] == null)
            {
                Session["MainMenu"] = Request.QueryString["MainMenu"];
                Session["MainMenuName"] = Request.QueryString["MainMenuName"];
                lblHeader.Text = Session["MainMenuName"].ToString();
                BindGrid(Session["MainMenu"].ToString());
                GetNote(Session["MainMenu"].ToString());
                lblHeader.Focus();
            }
            else if (Request.QueryString["MainMenu"] != null & Request.QueryString["SubMenuId"] != null & Request.QueryString["ChildMenuId"] == null)
            {
                Session["SubMenuId"] = Request.QueryString["SubMenuId"];
                Session["SubMenuName"] = Request.QueryString["SubMenuName"];
                Session["MainMenu"] = Request.QueryString["MainMenu"];
                lblHeader.Text = Session["SubMenuName"].ToString();
                BindGrid(Session["SubMenuId"].ToString());
                GetNote(Session["SubMenuId"].ToString());
                lblHeader.Focus();
            }
            else if (Request.QueryString["MainMenu"] != null & Request.QueryString["SubMenuId"] != null & Request.QueryString["ChildMenuId"] != null)
            {
                Session["MainMenu"] = Request.QueryString["MainMenu"];
                Session["SubMenuId"] = Request.QueryString["SubMenuId"];
                Session["ChildMenuId"] = Request.QueryString["ChildMenuId"];
                Session["ChildMenuName"] = Request.QueryString["ChildMenuName"];
                lblHeader.Text = Session["ChildMenuName"].ToString();
                BindGrid(Session["ChildMenuId"].ToString());
                GetNote(Session["ChildMenuId"].ToString());
                lblHeader.Focus();
            }
            else
            {
                Response.Redirect("~/Default.aspx");
            }
        }
    }

    public void inputcheck()
    {
        string url = Request.Url.ToString();
        foreach (string key in Request.QueryString)
            objsql.CheckInput(Request.QueryString[key]);
        foreach (string key in Request.Cookies)
            objsql.CheckInput(Request.Cookies[key].Value);
    }

    protected void GetNote(string Levelid)
    {
        try
        {
            dt = new DataTable();
            objBE.Flag = "R";
            dt = objDL.ContentManagment(objBE);
            if (dt.Rows.Count > 0)
            {
                if (Request.QueryString["MainMenu"] != null & Request.QueryString["SubMenuId"] == null & Request.QueryString["ChildMenuId"] == null)
                {
                    lblHeader.Text = dt.Rows[0]["MainMenuName"].ToString();
                    lblContent.Text = dt.Rows[0]["ContentDisc"].ToString();
                    fulink.Text = dt.Rows[0]["File_Name"].ToString();
                    if (dt.Rows[0]["Document_Images"].ToString() != "")
                    {
                        Repeater1.Visible = true;
                        Repeater1.DataSource = dt;
                        Repeater1.DataBind();
                    }
                    else
                    {
                        Repeater1.Visible = false;
                    }

                }
                else if (Request.QueryString["MainMenu"] != null & Request.QueryString["SubMenuId"] != null & Request.QueryString["ChildMenuId"] == null)
                {
                    lblHeader.Text = dt.Rows[0]["SubMenuName"].ToString();
                    lblContent.Text = dt.Rows[0]["ContentDisc"].ToString();
                    fulink.Text = dt.Rows[0]["File_Name"].ToString();
                    if (dt.Rows[0]["Document_Images"].ToString() != "")
                    {
                        Repeater1.Visible = true;
                        Repeater1.DataSource = dt;
                        Repeater1.DataBind();
                    }
                    else
                    {
                        Repeater1.Visible = false;
                    }

                }
                else if (Request.QueryString["MainMenu"] != null & Request.QueryString["SubMenuId"] != null & Request.QueryString["ChildMenuId"] != null)
                {
                    lblHeader.Text = dt.Rows[0]["ChildMenuName"].ToString();
                    lblContent.Text = dt.Rows[0]["ContentDisc"].ToString();
                    fulink.Text = dt.Rows[0]["File_Name"].ToString();
                    if (dt.Rows[0]["Document_Images"].ToString() != "")
                    {
                        Repeater1.Visible = true;
                        Repeater1.DataSource = dt;
                        Repeater1.DataBind();
                    }
                    else
                    {
                        Repeater1.Visible = false;
                    }
                }
            }
            else
            {
                lblContent.Text = "No Data Found";
                Session["MainMenu"] = null;
                Session["SubMenuId"] = null;
                Session["ChildMenuId"] = null;
                objBE.MainMenu = "";
                objBE.SubMenu = "";
                objBE.ChildMenu = "";
            }

            lblHeader.Focus();
        }
        catch (Exception ex)
        {
            ExceptionLogging.SendExcepToDB(ex, "", Request.ServerVariables["REMOTE_ADDR"].ToString());
            Response.Redirect("~/Error.aspx");
        }
    }

    protected void BindGrid(string LevelId)
    {
        try
        {
            objBE.Flag = "R";
            objBE.MainMenu = Session["MainMenu"].ToString();
            if (Session["SubMenuId"] != null)
            {
                objBE.SubMenu = Session["SubMenuId"].ToString();
            }
            if (Session["ChildMenuId"] != null)
            {
                objBE.ChildMenu = Session["ChildMenuId"].ToString();
            }
            //objBE.SubMenu = LevelId;
            dt = objDL.ContentManagment(objBE);
            if (dt.Rows.Count > 0)
            {
                if (dt.Rows[0]["Document_Images"].ToString() != "")
                {
                    Repeater1.DataSource = dt;
                    Repeater1.DataBind();
                }
            }
            else
            {
                Repeater1.Visible = false;
                Repeater1.DataSource = null;
                Repeater1.DataBind();
                objCommon.ShowAlertMessage("No data Found");
            }
            lblHeader.Focus();
        }
        catch (Exception ex)
        {
            ExceptionLogging.SendExcepToDB(ex, "", Request.ServerVariables["REMOTE_ADDR"].ToString());
            Response.Redirect("~/Error.aspx");
        }
    }

    protected void View(object sender, EventArgs e)
    {

        int id = int.Parse((sender as LinkButton).CommandArgument);
        objBE.Flag = "V";
        objBE.Id = id.ToString();
        DataTable dt = objDL.ContentManagment(objBE);
        if (dt.Rows.Count > 0)
        {
            string img = Convert.ToBase64String((byte[])dt.Rows[0]["Document_Images"]);

            if (!string.IsNullOrEmpty(img))
            {
                Response.Clear();
                Response.Buffer = true;
                Response.ContentType = "application/" + dt.Rows[0]["File_Type"].ToString();
                Response.AddHeader("content-disposition", "attachement;filename=" + dt.Rows[0]["File_Name"].ToString() + "." + dt.Rows[0]["File_Type"].ToString()); // to open file prompt Box open or Save file  
                Response.Charset = "";
                Response.Cache.SetCacheability(HttpCacheability.NoCache);
                Response.BinaryWrite((byte[])dt.Rows[0]["Document_Images"]);
                Response.End();
            }
        }
    }

    public string GetImage(object img)
    {
        if (img != DBNull.Value)
        {
            return "data:image/jpg;base64," + Convert.ToBase64String((byte[])img);
        }
        else
        {
            return "";
        }
    }
}