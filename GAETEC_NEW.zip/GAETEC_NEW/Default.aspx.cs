﻿using System;
using System.Data;
using System.Collections.Generic;
using System.Linq;
using System.Data.SqlClient;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using GAETEC_BE;
using GAETEC_DL;
using System.Configuration;
using System.Globalization;


public partial class _Default : System.Web.UI.Page
{
    Admin_BE Objbe = new Admin_BE();
    DataSet ds = new DataSet();
    CommonFuncs objcommon = new CommonFuncs();
    Admin_DL objDl = new Admin_DL();
    SampleSqlInjectionScreeningModule objsql = new SampleSqlInjectionScreeningModule();
    string Connkey = ConfigurationManager.ConnectionStrings["ConnGAETEC"].ConnectionString;

    protected void Page_Load(object sender, EventArgs e)
    {
        Page.MaintainScrollPositionOnPostBack = true;
        if (!IsPostBack)
        {

            sliderimages();
         
            BindRepeaterNotification();
            //BindRelatedLinks();
            //Calendar1.Caption = "TSPA Events Calander";
            //Calendar1.FirstDayOfWeek = FirstDayOfWeek.Sunday;
            //Calendar1.NextPrevFormat = NextPrevFormat.ShortMonth;
            //Calendar1.TitleFormat = TitleFormat.Month;
            //Calendar1.ShowGridLines = true;
            //Calendar1.DayStyle.Height = new Unit(50);
            //Calendar1.DayStyle.Width = new Unit(150);
            //Calendar1.DayStyle.HorizontalAlign = HorizontalAlign.Center;
            //Calendar1.DayStyle.VerticalAlign = VerticalAlign.Middle;
            //Calendar1.OtherMonthDayStyle.BackColor = System.Drawing.Color.AliceBlue;
        }
    }


    public string GetImage(object img)
    {
        if (img != DBNull.Value)
        {
            return "data:image/jpg;base64," + Convert.ToBase64String((byte[])img);
        }
        else
        {
            return "";
        }
    }
    protected void sliderimages()
    {
        DataTable dt = new DataTable();
        dt = objDl.GetSliderPageImages();
        if (dt.Rows.Count > 0)
        {
            Repeater2.DataSource = dt;
            Repeater2.DataBind();
        }
        else
        {
            Repeater2.DataSource = null;
            Repeater2.DataBind();
        }

    }





    public void inputcheck()
    {
        string url = Request.Url.ToString();
        foreach (string key in Request.QueryString)
            objsql.CheckInput(Request.QueryString[key]);
        foreach (string key in Request.Cookies)
            objsql.CheckInput(Request.Cookies[key].Value);
    }
   

    protected void Repeater1_ItemCommand1(object source, RepeaterCommandEventArgs e)
    {
        if (e.CommandName == "Download")
        {
            string id = e.CommandArgument.ToString();
            SqlCommand cmd = new SqlCommand("GAETEC_CM_Notifications_IUDR");
            cmd.Parameters.AddWithValue("@Id", id);
            cmd.Parameters.AddWithValue("@Flag", "V");
            ds = objDl.ExecuteSelect(cmd);
            if (ds.Tables[0].Rows.Count > 0)
            {
                if (!string.IsNullOrEmpty(Convert.ToBase64String((byte[])ds.Tables[0].Rows[0]["Document_Image"])))
                {
                    Response.Clear();
                    Response.Buffer = true;
                    Response.ContentType = "application/" + ds.Tables[0].Rows[0]["File_Type"].ToString();
                    Response.AddHeader("content-disposition", "attechement;filename=" + ds.Tables[0].Rows[0]["File_Name"].ToString() + "." + ds.Tables[0].Rows[0]["File_Type"].ToString()); // to open file prompt Box open or Save file  
                    Response.Charset = "";
                    Response.Cache.SetCacheability(HttpCacheability.NoCache);
                    Response.BinaryWrite((byte[])ds.Tables[0].Rows[0]["Document_Image"]);
                    Response.End();
                }
            }
        }
    }
    public void BindRepeaterNotification()
    {
        try
        {
            SqlCommand cmd = new SqlCommand("GAETEC_CM_Notifications_IUDR");
            ds = objDl.ExecuteSelect(cmd);
            if (ds.Tables[0].Rows.Count > 0)
            {
                Repeater1.DataSource = ds.Tables[0];
                Repeater1.DataBind();
            }
        }
        catch (Exception ex)
        {
            ExceptionLogging.SendExcepToDB(ex, "HomePage", Request.ServerVariables["REMOTE_ADDR"].ToString());
            Response.Redirect("../Error.aspx");
        }
    }


    //public void BindRelatedLinks()
    //{
    //    try
    //    {
    //        DataTable dt = new DataTable();
    //        Objbe.Flag = "R";
    //        dt = objDl.OtherLinks(Objbe);
    //        if (dt.Rows.Count > 0)
    //        {
    //            RptLinks.Visible = true;
    //            RptLinks.DataSource = dt;
    //            RptLinks.DataBind();
    //        }
    //    }
    //    catch (Exception ex)
    //    {
    //        ExceptionLogging.SendExcepToDB(ex, Session["UsrName"].ToString(), Request.ServerVariables["REMOTE_ADDR"].ToString());
    //        Response.Redirect("~/Error.aspx");
    //    }
    //}
}
