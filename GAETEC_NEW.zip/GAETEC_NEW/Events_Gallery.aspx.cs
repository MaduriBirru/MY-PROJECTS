﻿using System;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using GAETEC_BE;
using GAETEC_DL;
using System.Data;
using System.Data.SqlClient;

public partial class Events_Gallery : System.Web.UI.Page
{
    CommonFuncs objCommon = new CommonFuncs();
    Admin_BE objBE = new Admin_BE();
    Admin_DL objDL = new Admin_DL();
    DataSet ds = new DataSet();
    SampleSqlInjectionScreeningModule objsql = new SampleSqlInjectionScreeningModule();
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            inputcheck();
            BindData();
        }
    }
    public void inputcheck()
    {
        string url = Request.Url.ToString();
        foreach (string key in Request.QueryString)
            objsql.CheckInput(Request.QueryString[key]);
        foreach (string key in Request.Cookies)
            objsql.CheckInput(Request.Cookies[key].Value);
    }
    protected string GetActiveClass(int ItemIndex)
    {
        if (ItemIndex == 0)
        {
            return "active";
        }
        else
        {
            return "";
        }
    }

    private void BindImageRepeater()
    {

        //// lblName.Text = Request.QueryString["name"];
        // SqlCommand cmd = new SqlCommand("Sp_SelectEventPhotosbyId");
        // cmd.Parameters.AddWithValue("@Action","R1");
        // //cmd.Parameters.AddWithValue("@Flag", "R");
        // ds = objDL.ExecuteSelect(cmd);
        // if (ds.Tables[0].Rows.Count > 0)
        // {
        //     dtlEvents.DataSource = ds.Tables[0];
        //     dtlEvents.DataBind();
        // }
        // else
        // {
        //     lblContent.Visible = true;
        //     lblContent.Text = "No Data Found";
        // }
    }

    protected void View(object sender, EventArgs e)
    {
        try
        {
            int id = int.Parse((sender as LinkButton).CommandArgument);
            //Notifiobj.Flag = "R1";
            SqlCommand cmd = new SqlCommand("GAETEC_CM_Sp_SelectEventPhotosbyId");
            cmd.Parameters.AddWithValue("@Action", "R");
            cmd.Parameters.AddWithValue("@Id", id);
            ds = objDL.ExecuteSelect(cmd);
            if (ds.Tables[0].Rows.Count > 0)
            {
                dtGallery.DataSource = ds.Tables[0];
                dtGallery.DataBind();
                dtGallery.Visible = true;
            }
            else
            {
                dtGallery.Visible = false;
                objCommon.ShowAlertMessage("No Photos found");
            }
        }
        catch (Exception ex)
        {
            ExceptionLogging.SendExcepToDB(ex, "Events", Request.ServerVariables["REMOTE_ADDR"].ToString());
            Response.Redirect("../Error.aspx");
        }
    }

    public string GetImage(object img)
    {
        if (img != DBNull.Value)
        {
            return "data:image/jpg;base64," + Convert.ToBase64String((byte[])img);
        }
        else
        {
            return "";
        }
    }

    protected void BindData()
    {
        try
        {
            SqlCommand cmd = new SqlCommand("GAETEC_CM_Sp_GetEvents");
            ds = objDL.ExecuteSelect(cmd);
            if (ds.Tables[0].Rows.Count > 0)
            {
                GrdDisplay.DataSource = ds.Tables[0];
                GrdDisplay.DataBind();
            }
            else
            {
                GrdDisplay.EmptyDataText = "No Data Found";
            }
        }
        catch (Exception ex)
        {
            ExceptionLogging.SendExcepToDB(ex, "Events", Request.ServerVariables["REMOTE_ADDR"].ToString());
            Response.Redirect("../Error.aspx");
        }
    }
}