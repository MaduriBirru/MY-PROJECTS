﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using GAETEC_BE;
using GAETEC_DL;

public partial class Login : System.Web.UI.Page
{

    Login_BE objbe = new Login_BE();
    Login_DL objdl = new Login_DL();
    DataTable dt = new DataTable();
    CommonFuncs objCommon = new CommonFuncs();

    SampleSqlInjectionScreeningModule objsql = new SampleSqlInjectionScreeningModule();
    string ConnKey = ConfigurationManager.ConnectionStrings["ConnGAETEC"].ToString();

    protected void Page_Load(object sender, EventArgs e)
    {
        try
        {
            txtUname.Attributes.Add("autocomplete", "off");
            txtPwd.Attributes.Add("autocomplete", "off");
            if (!IsPostBack)
            {
                inputcheck();
                random();
                Session["KeyGenerator"] = Guid.NewGuid().ToString("N").Substring(0, 16);
                txtUname.Focus();
                getCaptchaImage();
            }
        }
        catch (Exception ex)
        {
            ExceptionLogging.SendExcepToDB(ex, "Login", Request.ServerVariables["REMOTE_ADDR"].ToString());
            Response.Redirect("~/Error.aspx");
        }
    }

    public void inputcheck()
    {
        string url = Request.Url.ToString();
        foreach (string key in Request.QueryString)
            objsql.CheckInput(Request.QueryString[key]);
        foreach (string key in Request.Cookies)
            objsql.CheckInput(Request.Cookies[key].Value);
    }
    public void ValidChars()
    {
        foreach (string key in Request.Form)
        {
            if (!key.Contains("__"))
            {
                objsql.CheckInput(Request.Form[key]);
            }
        }
    }
    protected bool CheckCaptcha()
    {
        if (captch.Text == "")
        {
            lblmsg.Text = "Enter Captcha Text";
            return false;
        }
        else if (captch.Text != ViewState["captchtext"].ToString())
        {
            lblmsg.Text = "Enter Captcha Text as shown in the image";
            captch.Text = "";
            return false;
        }
        else if (captch.Text == ViewState["captchtext"].ToString())
            return true;
        else
        {
            lblmsg.Text = "image code is not valid.";
            captch.Text = "";
            return false;
        }
        return true;
    }

    protected void btnLogin_Click(object sender, EventArgs e)
    {
        check();
        ////ValidChars();
        try
        {
            if (CheckCaptcha())
            {
                Login_DL objLogin = new Login_DL();
                DataTable dtLogin = objLogin.getLoginDetails(txtUname.Text, ConnKey);
                if (dtLogin.Rows.Count > 0)
                {
                    //if (dtLogin.Rows[0]["Active"].ToString() == "0")
                    //{
                    //    objCommon.ShowAlertMessage("Your account has been blocked temporarly due to too many attempts");
                    //    return;
                    //}
                    //else if (dtLogin.Rows[0]["IsLOgin"].ToString() == "True")
                    //{
                    //    objCommon.ShowAlertMessage("Not Valid Session");
                    //    return;
                    //}
                    string user = dtLogin.Rows[0]["Sno"].ToString();
                    string password = dtLogin.Rows[0]["Password"].ToString();
                    string StateCode = dtLogin.Rows[0]["StateCode"].ToString();
                    string role = dtLogin.Rows[0]["Role"].ToString().Trim();
                    string roleNm = dtLogin.Rows[0]["role_name"].ToString();

                    string myval = ShaEncrypt(Session["KeyGenerator"].ToString());
                    string value = ShaEncrypt(password.ToLower() + myval.ToLower());

                    if (txtPwdHash.Value == value.ToLower())
                    {
                        objLogin.UpdateLoginDetails(txtUname.Text, ConnKey, "A");
                        string guid = Guid.NewGuid().ToString();
                        Session["AuthToken"] = guid;
                        Response.ClearContent();
                        Response.Cookies.Add(new HttpCookie("AuthToken", guid));
                        Session["ConnKey"] = ConnKey;
                        Session["User"] = user;
                        //Session["LoginSno"] = objLogin.insertUserLoginStatus(txtUname.Text, DateTime.Now, Request.ServerVariables["REMOTE_ADDR"].ToString(), "Login Successful", ConnKey);
                        if (dtLogin.Rows[0]["Role"].ToString() == "1")
                        {
                            Session["Role"] = role;
                            Session["RoleName"] = roleNm;
                            Session["UsrName"] = txtUname.Text;
                            Application["Uname"] = txtUname.Text;
                            Session["StateCode"] = StateCode;
                            Response.Redirect("~/GAETEC_NEW/Admin/Notifications.aspx", false);

                        }
                    }
                    else
                    {
                        captch.Text = "";
                        ViewState["KeyGenerator"] = Guid.NewGuid().ToString("N").Substring(0, 16);
                        getCaptchaImage();

                        //        if (dtLogin.Rows[0]["Active"].ToString() == "0" || dtLogin.Rows[0]["Login_Attempt"].ToString() == "3")
                        //    {
                        //        objLogin.UpdateLoginDetails(txtUname.Text, ConnKey, "I");
                        //        objCommon.ShowAlertMessage("Your account has been blocked temporarly due to too many attempts");
                        //    }
                        //    else
                        //        objCommon.ShowAlertMessage("Invalid Username Details and you have" + (3 - Convert.ToInt32(dtLogin.Rows[0]["Login_Attempt"])) + "  attempts");
                        //}
                    }
                }
                else
                {
                    captch.Text = "";
                    ViewState["KeyGenerator"] = Guid.NewGuid().ToString("N").Substring(0, 16);
                    getCaptchaImage();
                    // objCommon.ShowAlertMessage("Invalid Username Details and you have" + (3 - Convert.ToInt32(dtLogin.Rows[0]["Login_Attempt"])) + "  attempts");
                    objCommon.ShowAlertMessage("Invalid Username Details");
                }
                //  }
                //else
                //{
                //    captch.Text = "";
                //    ViewState["KeyGenerator"] = Guid.NewGuid().ToString("N").Substring(0, 16);
                //    getCaptchaImage();
                //    lblmsg.Text = "The characters you entered didn't match.Please try again";

                //}
            }
        }
        catch (Exception ex)
        {
            ExceptionLogging.SendExcepToDB(ex, "Login Page", Request.ServerVariables["REMOTE_ADDR"].ToString());
            Response.Redirect("~/Error.aspx", false);
        }
    }

    public string ShaEncrypt(string Ptext)
    {
        string hash = "";
        System.Security.Cryptography.SHA256CryptoServiceProvider m1 = new System.Security.Cryptography.SHA256CryptoServiceProvider();
        byte[] s1 = System.Text.Encoding.ASCII.GetBytes(Ptext);
        s1 = m1.ComputeHash(s1);
        foreach (byte bt in s1)
        {
            hash = hash + bt.ToString("x2");
        }
        return hash;
    }

    public void getCaptchaImage()
    {
        Captcha ci = new Captcha();
        string text = Captcha.generateRandomCode();
        ViewState["captchtext"] = text;
        Image2.ImageUrl = "~/GAETEC_NEW/Assets/cpImg/cpImage.aspx?randomNo=" + text;
    }

    protected void btnImgRefresh_Click(object sender, ImageClickEventArgs e)
    {
        captch.Text = "";
        getCaptchaImage();
    }

    public void random()
    {
        try
        {
            string strString = "abcdefghijklmnpqrstuvwxyzABCDQEFGHIJKLMNOPQRSTUVWXYZ1234567890";
            string num = "";
            Random rm = new Random();
            for (int i = 0; i < 16; i++)
            {
                int randomcharindex = rm.Next(0, strString.Length);
                char randomchar = strString[randomcharindex];
                num += Convert.ToString(randomchar);
            }

            Response.Cookies.Add(new HttpCookie("ASPFIXATION2", num));
            hf.Value = num;
            Session["ASPFIXATION2"] = num;
        }
        catch (Exception ex)
        {
            Response.Redirect("~/Error.aspx", false);
        }
    }

    public void check()
    {
        try
        {
            string cookie_value = null;
            string session_value = null;
            //cookie_value = System.Web.HttpContext.Current.Request.Cookies["ASPFIXATION2"].Value;
            cookie_value = hf.Value;
            session_value = System.Web.HttpContext.Current.Session["ASPFIXATION2"].ToString();
            if (cookie_value != session_value)
            {
                System.Web.HttpContext.Current.Session.Abandon();
                HttpContext.Current.Response.Buffer = false;
                HttpContext.Current.Response.Redirect("~/Error.aspx", false);
            }
        }
        catch (Exception ex)
        {
            Response.Redirect("~/Error.aspx");
        }
    }
}
