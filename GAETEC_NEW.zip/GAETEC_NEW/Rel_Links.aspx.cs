﻿using System;
using System.Data;
using System.Collections.Generic;
using System.Linq;
using System.Data.SqlClient;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using GAETEC_BE;
using GAETEC_DL;
using System.Configuration;
using System.Globalization;


public partial class Rel_Links : System.Web.UI.Page
{
    Admin_BE Objbe = new Admin_BE();
    DataSet ds = new DataSet();
    CommonFuncs objcommon = new CommonFuncs();
    Admin_DL objDl = new Admin_DL();
    SampleSqlInjectionScreeningModule objsql = new SampleSqlInjectionScreeningModule();
    string Connkey = ConfigurationManager.ConnectionStrings["ConnGAETEC"].ConnectionString;

    protected void Page_Load(object sender, EventArgs e)
    {
        Page.MaintainScrollPositionOnPostBack = true;
        if (!IsPostBack)
        {


            BindRelatedLinks();
            //Calendar1.Caption = "TSPA Events Calander";
            //Calendar1.FirstDayOfWeek = FirstDayOfWeek.Sunday;
            //Calendar1.NextPrevFormat = NextPrevFormat.ShortMonth;
            //Calendar1.TitleFormat = TitleFormat.Month;
            //Calendar1.ShowGridLines = true;
            //Calendar1.DayStyle.Height = new Unit(50);
            //Calendar1.DayStyle.Width = new Unit(150);
            //Calendar1.DayStyle.HorizontalAlign = HorizontalAlign.Center;
            //Calendar1.DayStyle.VerticalAlign = VerticalAlign.Middle;
            //Calendar1.OtherMonthDayStyle.BackColor = System.Drawing.Color.AliceBlue;
        }
    }


    public void inputcheck()
    {
        string url = Request.Url.ToString();
        foreach (string key in Request.QueryString)
            objsql.CheckInput(Request.QueryString[key]);
        foreach (string key in Request.Cookies)
            objsql.CheckInput(Request.Cookies[key].Value);
    }





    public void BindRelatedLinks()
    {
        try
        {
            DataTable dt = new DataTable();
            Objbe.Flag = "R";
            dt = objDl.OtherLinks(Objbe);
            if (dt.Rows.Count > 0)
            {
                RptLinks.Visible = true;
                RptLinks.DataSource = dt;
                RptLinks.DataBind();
            }
        }
        catch (Exception ex)
        {
            ExceptionLogging.SendExcepToDB(ex, Session["UsrName"].ToString(), Request.ServerVariables["REMOTE_ADDR"].ToString());
            Response.Redirect("~/Error.aspx");
        }
    }
}
