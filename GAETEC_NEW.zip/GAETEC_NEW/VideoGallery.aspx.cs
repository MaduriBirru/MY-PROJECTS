﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Data;
using GAETEC_DL;

public partial class VideoGallery : System.Web.UI.Page
{
    DataSet ds = new DataSet();
    CommonFuncs objcommon = new CommonFuncs();
    Admin_DL objDl = new Admin_DL();
    SampleSqlInjectionScreeningModule objsql = new SampleSqlInjectionScreeningModule();

    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            BindData();
        }
        inputcheck();
    }

    public void inputcheck()
    {
        string url = Request.Url.ToString();
        foreach (string key in Request.QueryString)
            objsql.CheckInput(Request.QueryString[key]);
        foreach (string key in Request.Cookies)
            objsql.CheckInput(Request.Cookies[key].Value);
    }

    //protected void BindDataList()
    //{
    //    try
    //    {
    //        lblName.Text = Request.QueryString["name"];
    //        DirectoryInfo dir = new DirectoryInfo(MapPath("~/Videos"));
    //        FileInfo[] files = dir.GetFiles();
    //        ArrayList listItems = new ArrayList();
    //        foreach (FileInfo info in files)
    //        {
    //            listItems.Add(info);
    //        }
    //        if (listItems.Count > 0)
    //        {
    //            dtlVideos.DataSource = listItems;
    //            dtlVideos.DataBind();
    //        }
    //        else
    //        {
    //            objcommon.ShowAlertMessage("No Data Found");
    //        }

    //    }
    //    catch (Exception ex)
    //    {
    //        ExceptionLogging.SendExcepToDB(ex, "", Request.ServerVariables["REMOTE_ADDR"].ToString());
    //        Response.Redirect("~/Error.aspx");
    //    }
    //}

    protected void View(object sender, EventArgs e)
    {
        try
        {
            int id = int.Parse((sender as LinkButton).CommandArgument);
            SqlCommand cmd = new SqlCommand("VideoGallery_IUDR");
            cmd.Parameters.AddWithValue("@Flag", "R1");
            cmd.Parameters.AddWithValue("@Id", id);
            ds = objDl.ExecuteSelect(cmd);
            if (ds.Tables[0].Rows.Count > 0)
            {
                dtGallery.DataSource = ds.Tables[0];
                dtGallery.DataBind();
                dtGallery.Visible = true;
            }
            else
            {
                dtGallery.Visible = false;
                objcommon.ShowAlertMessage("No Photos found");
            }
        }
        catch (Exception ex)
        {
            ExceptionLogging.SendExcepToDB(ex, "HomeGallery", Request.ServerVariables["REMOTE_ADDR"].ToString());
            Response.Redirect("~/Error.aspx");
        }
    }

    protected void BindData()
    {
        try
        {
            SqlCommand cmd = new SqlCommand("VideoGallery_IUDR");
            cmd.Parameters.Add("@Flag", "R");
            ds = objDl.ExecuteSelect(cmd);
            if (ds.Tables[0].Rows.Count > 0)
            {
                GrdDisplay.DataSource = ds.Tables[0];
                GrdDisplay.DataBind();
            }
            else
            {
                GrdDisplay.EmptyDataText = "No Data Found";
            }
        }
        catch (Exception ex)
        {
            ExceptionLogging.SendExcepToDB(ex, "HomeVideoGallery", Request.ServerVariables["REMOTE_ADDR"].ToString());
            Response.Redirect("~/Error.aspx");
        }
    }
}